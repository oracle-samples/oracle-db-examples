cd   "/home/oracle/Desktop/Parallels Shared Folders/Home/Documents/Bllewell_Documents/Work/Plsql_PM/Streaming_Dbms_Output/2015_April/Perl_Listener"
perl "/home/oracle/Desktop/Parallels Shared Folders/Home/Documents/Bllewell_Documents/Work/Plsql_PM/Streaming_Dbms_Output/2015_April/Perl_Listener/Dbms_Output_Listener.pl"
