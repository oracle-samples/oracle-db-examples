create or replace package body dbms_output as

-- DE-HEAD     <- tell SED where to cut when generating fixed package

  enabled         boolean        := FALSE;
  buf_size        binary_integer;
  linebuflen      binary_integer := 0; -- byte length in a line
  putidx          binary_integer := 1;
  getidx          binary_integer := 2;
  get_in_progress boolean := TRUE;
  type            char_arr is table of varchar2(32767) index by binary_integer;
  buf             char_arr;
  bufleft         binary_integer := -1;

---------------------------------------------------------------------
-- local copy of raise_application_error, needed by the fixed package
-- but used by both the fixed and non-fixed implementations.
---------------------------------------------------------------------

PROCEDURE kkxerae(
   num binary_integer
  ,msg varchar2
  ,keeperrorstack boolean default FALSE);
PRAGMA interface (C, kkxerae);

PROCEDURE raise_application_error(
   num binary_integer
  ,msg varchar2
  ,keeperrorstack boolean default FALSE)
IS
BEGIN
  kkxerae(num, msg, keeperrorstack);
END raise_application_error;

  --
  -- Passing buffer_size as null to specify that the buffer size should be
  -- unlimited.
  -- This feature is already used by RMAN to buffer debug outputs. 
  --
  procedure enable (buffer_size in integer default 20000) is
    lstatus integer;
    lockid  integer;
  begin
    enabled := TRUE;
    if buffer_size < 2000 then
      buf_size := 2000;
    elsif buffer_size > 1000000 then
      buf_size := 1000000;
    elsif buffer_size IS NULL then
      buf_size := -1;   -- indicate unlimited buffer_size
    else
      buf_size := buffer_size;
    end if;
    bufleft := buf_size;
  end;

  procedure disable is
  begin
    enabled := FALSE;

    buf.delete;         -- free up memory
    putidx      := 1;
    buf(putidx) := '';
    get_in_progress := TRUE;
  end;

  procedure put_init is
  begin
    buf.delete;
    putidx := 1;
    buf(putidx) := '';
    linebuflen := 0;
    bufleft := buf_size;
    get_in_progress := FALSE;
  end;

  procedure put(a varchar2) is
    strlen  binary_integer;
  begin
    if enabled then
      if get_in_progress then
        put_init;
      end if;

-- The upper limit for a varchar2 is 32767 bytes regardless of BYTE or CHAR
-- semantics sepcified in NLS_LENGTH_SEMANTICS initialization parameter.
-- 10028 error is raised if exceed 32767 bytes.
      strlen := NVL(lengthb(a), 0);
      if ((strlen + linebuflen) > 32767) then
        linebuflen := 0; buf(putidx) := '';
        raise_application_error(-20000, 'ORU-10028: line length overflow, ' ||
          'limit of 32767 bytes per line');
      end if;

      if (buf_size <> -1) then   -- if unlimited, skip buffer overflow check
        if (strlen > bufleft) then
            raise_application_error(-20000, 'ORU-10027: buffer overflow, ' ||
              'limit of ' || to_char(buf_size) || ' bytes');
        end if;
        bufleft := bufleft - strlen;
      end if;

      buf(putidx) := buf(putidx) || a;
      linebuflen := linebuflen + strlen;

    end if;
  end;

  procedure put_line(a varchar2) is
  begin
    if enabled then
      put(a);
      new_line;
    end if;
  end;

  procedure new_line is
  begin
    if enabled then
      if get_in_progress then
        put_init;
      end if;
      linebuflen := 0;
      putidx := putidx + 1;
      buf(putidx) := '';
    end if;
  end;

  procedure get_line(line out varchar2, status out integer) is
  begin
    if not enabled then
      status := 1;
      return;
    end if;

    if not get_in_progress then
      -- terminate last line
      if (linebuflen > 0) and (putidx = 1) then
        status := 1;
        return;
      end if;
      get_in_progress := TRUE;
      -- initialize for reading
      getidx := 1;
    end if;

    while getidx < putidx loop
      line := buf(getidx);
      getidx := getidx + 1;
      status := 0;
      return;
    end loop;
    status := 1;
    return;
  end;

  procedure get_lines(lines out chararr, numlines in out integer) is
    linecnt integer := 1;
    s       integer;
  begin
    if not enabled then
      numlines := 0;
      return;
    end if;
    while linecnt <= numlines loop
      get_line(lines(linecnt), s);
      if s = 1 then                     -- no more data
        numlines := linecnt - 1;
        return;
      end if;
      linecnt := linecnt + 1;           -- successfully got a line
    end loop;
    numlines := linecnt - 1;
    return;
  end;

  procedure get_lines(lines out dbmsoutput_linesarray, numlines in out integer)
  is
    linecnt integer := 1;
    s       integer;
    n       integer;
  begin
    if not enabled then
      numlines := 0;
      return;
    end if;

    lines := dbmsoutput_linesarray();
    lines.delete;

    if numlines < buf.count then
      n := numlines;
    else
      n := buf.count;
    end if;

    lines.extend(n);
    while linecnt <= n loop
      get_line(lines(linecnt), s);
      if s = 1 then                     -- no more data
        numlines := linecnt - 1;
        return;
      end if;
      linecnt := linecnt + 1;           -- successfully got a line
    end loop;
    numlines := linecnt - 1;
    return;
  end;

end;
/
