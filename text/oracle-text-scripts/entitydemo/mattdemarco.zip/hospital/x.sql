drop table test_sentence;

create table test_sentence(id number primary key, text varchar2(100));

insert into test_sentence values (1,'<INFO>Green Red Yellow. Blue Brown</INFO>');
commit;

exec ctx_ddl.drop_section_group('xmlgroup')

begin
  ctx_ddl.create_section_group('xmlgroup', 'XML_SECTION_GROUP');
  ctx_ddl.add_field_section('xmlgroup', 'INFO', 'INFO', TRUE);
  --         note the section is defined as visible     ^^^^
  ctx_ddl.add_special_section('xmlgroup', 'SENTENCE');
end;
/


create index sentence_idx on test_sentence(text) indextype is ctxsys.context
  parameters('section group xmlgroup');


select token_text,token_type from dr$sentence_idx$i;

select * from test_sentence where contains (text, '(green and yellow) within info') > 0;
select * from test_sentence where contains (text, '(green and yellow) within sentence') > 0;
