There was a requirement to regularly flush the KGL cache in the kernal
I can't remember quite why, but it was something to do with cleaning up 
the text data dictionary. This procedure forces a KGL flush every minute
