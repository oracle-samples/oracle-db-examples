Show that Oracle Text indexes work with transportable tablespaces
