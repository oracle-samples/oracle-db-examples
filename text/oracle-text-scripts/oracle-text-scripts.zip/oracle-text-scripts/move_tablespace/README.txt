Various scripts written to move an index into a new tablespace. Requires index rebuild.
