open out_file, ">t.txt";
print out_file "Hello perl\n";
close out_file;
