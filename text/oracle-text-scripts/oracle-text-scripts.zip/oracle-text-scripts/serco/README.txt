Examples of simple user datastores and procedures to test them
