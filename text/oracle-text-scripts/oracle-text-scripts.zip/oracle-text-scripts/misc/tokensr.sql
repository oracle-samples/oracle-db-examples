print 'FINALE'
select count(*) from unisys.dbo.news where contains (text, 'FINALE')
print 'AGGIUNTO'
select count(*) from unisys.dbo.news where contains (text, 'AGGIUNTO')
print 'MOMENTO'
select count(*) from unisys.dbo.news where contains (text, 'MOMENTO')
print 'FORSE'
select count(*) from unisys.dbo.news where contains (text, 'FORSE')
print 'MARTED�'
select count(*) from unisys.dbo.news where contains (text, 'MARTED�')
print 'INTORNO'
select count(*) from unisys.dbo.news where contains (text, 'INTORNO')
print 'PERSONE'
select count(*) from unisys.dbo.news where contains (text, 'PERSONE')
print 'PUNTO'
select count(*) from unisys.dbo.news where contains (text, 'PUNTO')
print 'VITTORIA'
select count(*) from unisys.dbo.news where contains (text, 'VITTORIA')
print 'ATTESA'
select count(*) from unisys.dbo.news where contains (text, 'ATTESA')
print 'LIBERO'
select count(*) from unisys.dbo.news where contains (text, 'LIBERO')
print 'INTERNO'
select count(*) from unisys.dbo.news where contains (text, 'INTERNO')
print 'EUROPA'
select count(*) from unisys.dbo.news where contains (text, 'EUROPA')
print 'CENTRALE'
select count(*) from unisys.dbo.news where contains (text, 'CENTRALE')
print 'VISTO'
select count(*) from unisys.dbo.news where contains (text, 'VISTO')
print 'SOCIET�'
select count(*) from unisys.dbo.news where contains (text, 'SOCIET�')
print 'COMMISSIONE'
select count(*) from unisys.dbo.news where contains (text, 'COMMISSIONE')
print 'SPECIE'
select count(*) from unisys.dbo.news where contains (text, 'SPECIE')
print 'SCORSA'
select count(*) from unisys.dbo.news where contains (text, 'SCORSA')
print 'GIORNALISTI'
select count(*) from unisys.dbo.news where contains (text, 'GIORNALISTI')
print 'VICINO'
select count(*) from unisys.dbo.news where contains (text, 'VICINO')
print 'RESPONSABILIT�'
select count(*) from unisys.dbo.news where contains (text, 'RESPONSABILIT�')
print 'VEDERE'
select count(*) from unisys.dbo.news where contains (text, 'VEDERE')
print 'MILANO'
select count(*) from unisys.dbo.news where contains (text, 'MILANO')
print 'APPUNTO'
select count(*) from unisys.dbo.news where contains (text, 'APPUNTO')
print 'PROGETTO'
select count(*) from unisys.dbo.news where contains (text, 'PROGETTO')
print 'RICHIESTA'
select count(*) from unisys.dbo.news where contains (text, 'RICHIESTA')
print 'MASSIMO'
select count(*) from unisys.dbo.news where contains (text, 'MASSIMO')
print 'LIBERT�'
select count(*) from unisys.dbo.news where contains (text, 'LIBERT�')
print 'CONTI'
select count(*) from unisys.dbo.news where contains (text, 'CONTI')
print 'TOTALE'
select count(*) from unisys.dbo.news where contains (text, 'TOTALE')
print 'FUOCO'
select count(*) from unisys.dbo.news where contains (text, 'FUOCO')
print 'BISOGNA'
select count(*) from unisys.dbo.news where contains (text, 'BISOGNA')
print 'CAMPO'
select count(*) from unisys.dbo.news where contains (text, 'CAMPO')
print 'LUCE'
select count(*) from unisys.dbo.news where contains (text, 'LUCE')
print 'COSTA'
select count(*) from unisys.dbo.news where contains (text, 'COSTA')
print 'COMUNALE'
select count(*) from unisys.dbo.news where contains (text, 'COMUNALE')
print 'DAVANTI'
select count(*) from unisys.dbo.news where contains (text, 'DAVANTI')
print 'DONNE'
select count(*) from unisys.dbo.news where contains (text, 'DONNE')
print 'PARLARE'
select count(*) from unisys.dbo.news where contains (text, 'PARLARE')
print 'BISOGNO'
select count(*) from unisys.dbo.news where contains (text, 'BISOGNO')
print 'GERMANIA'
select count(*) from unisys.dbo.news where contains (text, 'GERMANIA')
print 'PRENDERE'
select count(*) from unisys.dbo.news where contains (text, 'PRENDERE')
print 'SERIE'
select count(*) from unisys.dbo.news where contains (text, 'SERIE')
print 'IPOTESI'
select count(*) from unisys.dbo.news where contains (text, 'IPOTESI')
print 'CINEMA'
select count(*) from unisys.dbo.news where contains (text, 'CINEMA')
print 'SERVIZI'
select count(*) from unisys.dbo.news where contains (text, 'SERVIZI')
print 'COMPAGNIA'
select count(*) from unisys.dbo.news where contains (text, 'COMPAGNIA')
print 'GRUPPI'
select count(*) from unisys.dbo.news where contains (text, 'GRUPPI')
print 'LAVORI'
select count(*) from unisys.dbo.news where contains (text, 'LAVORI')
print 'MIGLIORE'
select count(*) from unisys.dbo.news where contains (text, 'MIGLIORE')
print 'AUMENTO'
select count(*) from unisys.dbo.news where contains (text, 'AUMENTO')
print 'RAGGIUNTO'
select count(*) from unisys.dbo.news where contains (text, 'RAGGIUNTO')
print 'PROBLEMA'
select count(*) from unisys.dbo.news where contains (text, 'PROBLEMA')
print 'COLPO'
select count(*) from unisys.dbo.news where contains (text, 'COLPO')
print 'GIORNO'
select count(*) from unisys.dbo.news where contains (text, 'GIORNO')
print 'PUNTA'
select count(*) from unisys.dbo.news where contains (text, 'PUNTA')
print 'FORMAZIONE'
select count(*) from unisys.dbo.news where contains (text, 'FORMAZIONE')
print 'SCENA'
select count(*) from unisys.dbo.news where contains (text, 'SCENA')
print 'ULTIMA'
select count(*) from unisys.dbo.news where contains (text, 'ULTIMA')
print 'PAOLO'
select count(*) from unisys.dbo.news where contains (text, 'PAOLO')
print 'OPERA'
select count(*) from unisys.dbo.news where contains (text, 'OPERA')
print 'ATTO'
select count(*) from unisys.dbo.news where contains (text, 'ATTO')
print 'BASTA'
select count(*) from unisys.dbo.news where contains (text, 'BASTA')
print 'CORSO'
select count(*) from unisys.dbo.news where contains (text, 'CORSO')
print 'TECNICO'
select count(*) from unisys.dbo.news where contains (text, 'TECNICO')
print 'PARTI'
select count(*) from unisys.dbo.news where contains (text, 'PARTI')
print 'LETTO'
select count(*) from unisys.dbo.news where contains (text, 'LETTO')
print 'GIOCO'
select count(*) from unisys.dbo.news where contains (text, 'GIOCO')
print 'DIVERSE'
select count(*) from unisys.dbo.news where contains (text, 'DIVERSE')
print 'MAGGIORANZA'
select count(*) from unisys.dbo.news where contains (text, 'MAGGIORANZA')
print 'FACCIA'
select count(*) from unisys.dbo.news where contains (text, 'FACCIA')
print 'DICEMBRE'
select count(*) from unisys.dbo.news where contains (text, 'DICEMBRE')
print 'METTERE'
select count(*) from unisys.dbo.news where contains (text, 'METTERE')
print 'CORSA'
select count(*) from unisys.dbo.news where contains (text, 'CORSA')
print 'INSOMMA'
select count(*) from unisys.dbo.news where contains (text, 'INSOMMA')
print 'TORINESE'
select count(*) from unisys.dbo.news where contains (text, 'TORINESE')
print 'SCELTA'
select count(*) from unisys.dbo.news where contains (text, 'SCELTA')
print 'POSTI'
select count(*) from unisys.dbo.news where contains (text, 'POSTI')
print 'LASCIATO'
select count(*) from unisys.dbo.news where contains (text, 'LASCIATO')
print 'CIO�'
select count(*) from unisys.dbo.news where contains (text, 'CIO�')
print 'FEBBRAIO'
select count(*) from unisys.dbo.news where contains (text, 'FEBBRAIO')
print 'OPERAZIONE'
select count(*) from unisys.dbo.news where contains (text, 'OPERAZIONE')
print 'DATA'
select count(*) from unisys.dbo.news where contains (text, 'DATA')
print 'STRADA'
select count(*) from unisys.dbo.news where contains (text, 'STRADA')
print 'BAMBINI'
select count(*) from unisys.dbo.news where contains (text, 'BAMBINI')
print 'POSSIBILIT�'
select count(*) from unisys.dbo.news where contains (text, 'POSSIBILIT�')
print 'SICURO'
select count(*) from unisys.dbo.news where contains (text, 'SICURO')
print 'LEADER'
select count(*) from unisys.dbo.news where contains (text, 'LEADER')
print 'EUROPEO'
select count(*) from unisys.dbo.news where contains (text, 'EUROPEO')
print 'CARLO'
select count(*) from unisys.dbo.news where contains (text, 'CARLO')
print 'RETE'
select count(*) from unisys.dbo.news where contains (text, 'RETE')
print 'RISPONDE'
select count(*) from unisys.dbo.news where contains (text, 'RISPONDE')
print 'FRONTE'
select count(*) from unisys.dbo.news where contains (text, 'FRONTE')
print 'PREZZO'
select count(*) from unisys.dbo.news where contains (text, 'PREZZO')
print 'FIGLI'
select count(*) from unisys.dbo.news where contains (text, 'FIGLI')
print 'DOMENICA'
select count(*) from unisys.dbo.news where contains (text, 'DOMENICA')
print 'FORTE'
select count(*) from unisys.dbo.news where contains (text, 'FORTE')
print 'FANNO'
select count(*) from unisys.dbo.news where contains (text, 'FANNO')
print 'RESTA'
select count(*) from unisys.dbo.news where contains (text, 'RESTA')
print 'INGLESE'
select count(*) from unisys.dbo.news where contains (text, 'INGLESE')
print 'FORMA'
select count(*) from unisys.dbo.news where contains (text, 'FORMA')
print 'LOCALI'
select count(*) from unisys.dbo.news where contains (text, 'LOCALI')
print 'PARI'
select count(*) from unisys.dbo.news where contains (text, 'PARI')
print 'UFFICIO'
select count(*) from unisys.dbo.news where contains (text, 'UFFICIO')
print 'PRESTO'
select count(*) from unisys.dbo.news where contains (text, 'PRESTO')
print 'MEGLIO'
select count(*) from unisys.dbo.news where contains (text, 'MEGLIO')
print 'PORTA'
select count(*) from unisys.dbo.news where contains (text, 'PORTA')
print 'MORTE'
select count(*) from unisys.dbo.news where contains (text, 'MORTE')
print 'SOCIALE'
select count(*) from unisys.dbo.news where contains (text, 'SOCIALE')
print 'RIPRESA'
select count(*) from unisys.dbo.news where contains (text, 'RIPRESA')
print 'SUBITO'
select count(*) from unisys.dbo.news where contains (text, 'SUBITO')
print 'PARIGI'
select count(*) from unisys.dbo.news where contains (text, 'PARIGI')
print 'GRANDI'
select count(*) from unisys.dbo.news where contains (text, 'GRANDI')
print 'CAUSA'
select count(*) from unisys.dbo.news where contains (text, 'CAUSA')
print 'MESSA'
select count(*) from unisys.dbo.news where contains (text, 'MESSA')
print 'POLITICI'
select count(*) from unisys.dbo.news where contains (text, 'POLITICI')
print 'REALT�'
select count(*) from unisys.dbo.news where contains (text, 'REALT�')
print 'UNICA'
select count(*) from unisys.dbo.news where contains (text, 'UNICA')
print 'PARTITA'
select count(*) from unisys.dbo.news where contains (text, 'PARTITA')
print 'CONDIZIONI'
select count(*) from unisys.dbo.news where contains (text, 'CONDIZIONI')
print 'QUOTA'
select count(*) from unisys.dbo.news where contains (text, 'QUOTA')
print 'DARE'
select count(*) from unisys.dbo.news where contains (text, 'DARE')
print 'CAPIRE'
select count(*) from unisys.dbo.news where contains (text, 'CAPIRE')
print 'NUOVA'
select count(*) from unisys.dbo.news where contains (text, 'NUOVA')
print 'COMUNE'
select count(*) from unisys.dbo.news where contains (text, 'COMUNE')
print 'NUOVE'
select count(*) from unisys.dbo.news where contains (text, 'NUOVE')
print 'MADRE'
select count(*) from unisys.dbo.news where contains (text, 'MADRE')
print 'SEDE'
select count(*) from unisys.dbo.news where contains (text, 'SEDE')
print 'LUOGO'
select count(*) from unisys.dbo.news where contains (text, 'LUOGO')
print 'CLASSIFICA'
select count(*) from unisys.dbo.news where contains (text, 'CLASSIFICA')
print 'FRANCESCO'
select count(*) from unisys.dbo.news where contains (text, 'FRANCESCO')
print 'BENE'
select count(*) from unisys.dbo.news where contains (text, 'BENE')
print 'CALCIO'
select count(*) from unisys.dbo.news where contains (text, 'CALCIO')
print 'ALMENO'
select count(*) from unisys.dbo.news where contains (text, 'ALMENO')
print 'AVANTI'
select count(*) from unisys.dbo.news where contains (text, 'AVANTI')
print 'VITTORIO'
select count(*) from unisys.dbo.news where contains (text, 'VITTORIO')
print 'APERTO'
select count(*) from unisys.dbo.news where contains (text, 'APERTO')
print 'STAGIONE'
select count(*) from unisys.dbo.news where contains (text, 'STAGIONE')
print 'ISTITUTO'
select count(*) from unisys.dbo.news where contains (text, 'ISTITUTO')
print 'UNITI'
select count(*) from unisys.dbo.news where contains (text, 'UNITI')
print 'MAGGIORE'
select count(*) from unisys.dbo.news where contains (text, 'MAGGIORE')
print 'QUALIT�'
select count(*) from unisys.dbo.news where contains (text, 'QUALIT�')
print 'AMICI'
select count(*) from unisys.dbo.news where contains (text, 'AMICI')
print 'PIAZZA'
select count(*) from unisys.dbo.news where contains (text, 'PIAZZA')
print 'FAMIGLIA'
select count(*) from unisys.dbo.news where contains (text, 'FAMIGLIA')
print 'ESPERIENZA'
select count(*) from unisys.dbo.news where contains (text, 'ESPERIENZA')
print 'LUNGA'
select count(*) from unisys.dbo.news where contains (text, 'LUNGA')
print 'ATTUALE'
select count(*) from unisys.dbo.news where contains (text, 'ATTUALE')
print 'PICCOLI'
select count(*) from unisys.dbo.news where contains (text, 'PICCOLI')
print 'TERRA'
select count(*) from unisys.dbo.news where contains (text, 'TERRA')
print 'LASCIA'
select count(*) from unisys.dbo.news where contains (text, 'LASCIA')
print 'APPUNTAMENTO'
select count(*) from unisys.dbo.news where contains (text, 'APPUNTAMENTO')
print 'MESE'
select count(*) from unisys.dbo.news where contains (text, 'MESE')
print 'SUCCESSO'
select count(*) from unisys.dbo.news where contains (text, 'SUCCESSO')
print 'VARI'
select count(*) from unisys.dbo.news where contains (text, 'VARI')
print 'MAURIZIO'
select count(*) from unisys.dbo.news where contains (text, 'MAURIZIO')
print 'ACCORDO'
select count(*) from unisys.dbo.news where contains (text, 'ACCORDO')
print 'ARRIVA'
select count(*) from unisys.dbo.news where contains (text, 'ARRIVA')
print 'QUESTIONE'
select count(*) from unisys.dbo.news where contains (text, 'QUESTIONE')
print 'COMUNQUE'
select count(*) from unisys.dbo.news where contains (text, 'COMUNQUE')
print 'PIENO'
select count(*) from unisys.dbo.news where contains (text, 'PIENO')
print 'VUOL'
select count(*) from unisys.dbo.news where contains (text, 'VUOL')
print 'PERIODO'
select count(*) from unisys.dbo.news where contains (text, 'PERIODO')
print 'VERIT�'
select count(*) from unisys.dbo.news where contains (text, 'VERIT�')
print 'SAPERE'
select count(*) from unisys.dbo.news where contains (text, 'SAPERE')
print 'VIENE'
select count(*) from unisys.dbo.news where contains (text, 'VIENE')
print 'PADRE'
select count(*) from unisys.dbo.news where contains (text, 'PADRE')
print 'ITALIANO'
select count(*) from unisys.dbo.news where contains (text, 'ITALIANO')
print 'AMBIENTE'
select count(*) from unisys.dbo.news where contains (text, 'AMBIENTE')
print 'TEMA'
select count(*) from unisys.dbo.news where contains (text, 'TEMA')
print 'PARTIRE'
select count(*) from unisys.dbo.news where contains (text, 'PARTIRE')
print 'DIFFICOLT�'
select count(*) from unisys.dbo.news where contains (text, 'DIFFICOLT�')
print 'POSIZIONE'
select count(*) from unisys.dbo.news where contains (text, 'POSIZIONE')
print 'PIANO'
select count(*) from unisys.dbo.news where contains (text, 'PIANO')
print 'SEMPLICE'
select count(*) from unisys.dbo.news where contains (text, 'SEMPLICE')
print 'ALTO'
select count(*) from unisys.dbo.news where contains (text, 'ALTO')
print 'MANO'
select count(*) from unisys.dbo.news where contains (text, 'MANO')
print 'OTTOBRE'
select count(*) from unisys.dbo.news where contains (text, 'OTTOBRE')
print 'PERSONALE'
select count(*) from unisys.dbo.news where contains (text, 'PERSONALE')
print 'SEGUITO'
select count(*) from unisys.dbo.news where contains (text, 'SEGUITO')
print 'MANI'
select count(*) from unisys.dbo.news where contains (text, 'MANI')
print 'SPIEGATO'
select count(*) from unisys.dbo.news where contains (text, 'SPIEGATO')
print 'SOLE'
select count(*) from unisys.dbo.news where contains (text, 'SOLE')
print 'UNIONE'
select count(*) from unisys.dbo.news where contains (text, 'UNIONE')
print 'ATTENZIONE'
select count(*) from unisys.dbo.news where contains (text, 'ATTENZIONE')
print 'FARSI'
select count(*) from unisys.dbo.news where contains (text, 'FARSI')
print 'OTTENERE'
select count(*) from unisys.dbo.news where contains (text, 'OTTENERE')
print 'CARCERE'
select count(*) from unisys.dbo.news where contains (text, 'CARCERE')
print 'AUTORIT�'
select count(*) from unisys.dbo.news where contains (text, 'AUTORIT�')
print 'SERGIO'
select count(*) from unisys.dbo.news where contains (text, 'SERGIO')
print 'CHIUSO'
select count(*) from unisys.dbo.news where contains (text, 'CHIUSO')
print 'PRIMI'
select count(*) from unisys.dbo.news where contains (text, 'PRIMI')
print 'SPERANZA'
select count(*) from unisys.dbo.news where contains (text, 'SPERANZA')
print 'ANTONIO'
select count(*) from unisys.dbo.news where contains (text, 'ANTONIO')
print 'TITOLI'
select count(*) from unisys.dbo.news where contains (text, 'TITOLI')
print 'ESISTE'
select count(*) from unisys.dbo.news where contains (text, 'ESISTE')
print 'PROSSIMA'
select count(*) from unisys.dbo.news where contains (text, 'PROSSIMA')
print 'PARTICOLARE'
select count(*) from unisys.dbo.news where contains (text, 'PARTICOLARE')
print 'AUTO'
select count(*) from unisys.dbo.news where contains (text, 'AUTO')
print 'FINORA'
select count(*) from unisys.dbo.news where contains (text, 'FINORA')
print 'CONTROLLO'
select count(*) from unisys.dbo.news where contains (text, 'CONTROLLO')
print 'ATTIVIT�'
select count(*) from unisys.dbo.news where contains (text, 'ATTIVIT�')
print 'FORZA'
select count(*) from unisys.dbo.news where contains (text, 'FORZA')
print 'GENITORI'
select count(*) from unisys.dbo.news where contains (text, 'GENITORI')
print 'NOTA'
select count(*) from unisys.dbo.news where contains (text, 'NOTA')
print 'DONNA'
select count(*) from unisys.dbo.news where contains (text, 'DONNA')
print 'AVER'
select count(*) from unisys.dbo.news where contains (text, 'AVER')
print 'VALORE'
select count(*) from unisys.dbo.news where contains (text, 'VALORE')
print 'MERCATO'
select count(*) from unisys.dbo.news where contains (text, 'MERCATO')
print 'PARLAMENTO'
select count(*) from unisys.dbo.news where contains (text, 'PARLAMENTO')
print 'FINITO'
select count(*) from unisys.dbo.news where contains (text, 'FINITO')
print 'MARZO'
select count(*) from unisys.dbo.news where contains (text, 'MARZO')
print 'ULTIMO'
select count(*) from unisys.dbo.news where contains (text, 'ULTIMO')
print 'PARLA'
select count(*) from unisys.dbo.news where contains (text, 'PARLA')
print 'CAMERA'
select count(*) from unisys.dbo.news where contains (text, 'CAMERA')
print 'PROTAGONISTA'
select count(*) from unisys.dbo.news where contains (text, 'PROTAGONISTA')
print 'FASE'
select count(*) from unisys.dbo.news where contains (text, 'FASE')
print 'DIRETTA'
select count(*) from unisys.dbo.news where contains (text, 'DIRETTA')
print 'BRUNO'
select count(*) from unisys.dbo.news where contains (text, 'BRUNO')
print 'SPAZIO'
select count(*) from unisys.dbo.news where contains (text, 'SPAZIO')
print 'SEGNO'
select count(*) from unisys.dbo.news where contains (text, 'SEGNO')
print 'PUNTI'
select count(*) from unisys.dbo.news where contains (text, 'PUNTI')
print 'CHIARO'
select count(*) from unisys.dbo.news where contains (text, 'CHIARO')
print 'STUDIO'
select count(*) from unisys.dbo.news where contains (text, 'STUDIO')
print 'USCITA'
select count(*) from unisys.dbo.news where contains (text, 'USCITA')
print 'NAPOLI'
select count(*) from unisys.dbo.news where contains (text, 'NAPOLI')
print 'MATTINA'
select count(*) from unisys.dbo.news where contains (text, 'MATTINA')
print 'INGRESSO'
select count(*) from unisys.dbo.news where contains (text, 'INGRESSO')
print 'FACENDO'
select count(*) from unisys.dbo.news where contains (text, 'FACENDO')
print 'STAVA'
select count(*) from unisys.dbo.news where contains (text, 'STAVA')
print 'GENNAIO'
select count(*) from unisys.dbo.news where contains (text, 'GENNAIO')
print 'PICCOLO'
select count(*) from unisys.dbo.news where contains (text, 'PICCOLO')
print 'PIETRO'
select count(*) from unisys.dbo.news where contains (text, 'PIETRO')
print 'UNIT�'
select count(*) from unisys.dbo.news where contains (text, 'UNIT�')
print 'CHIEDERE'
select count(*) from unisys.dbo.news where contains (text, 'CHIEDERE')
print 'AMMINISTRAZIONE'
select count(*) from unisys.dbo.news where contains (text, 'AMMINISTRAZIONE')
print 'CERTO'
select count(*) from unisys.dbo.news where contains (text, 'CERTO')
print 'TROVATO'
select count(*) from unisys.dbo.news where contains (text, 'TROVATO')
print 'SULL'
select count(*) from unisys.dbo.news where contains (text, 'SULL')
print 'NOME'
select count(*) from unisys.dbo.news where contains (text, 'NOME')
print 'SOSTIENE'
select count(*) from unisys.dbo.news where contains (text, 'SOSTIENE')
print 'SPALLE'
select count(*) from unisys.dbo.news where contains (text, 'SPALLE')
print 'PAGINE'
select count(*) from unisys.dbo.news where contains (text, 'PAGINE')
print 'ALLORA'
select count(*) from unisys.dbo.news where contains (text, 'ALLORA')
print 'LAVORO'
select count(*) from unisys.dbo.news where contains (text, 'LAVORO')
print 'ESEMPIO'
select count(*) from unisys.dbo.news where contains (text, 'ESEMPIO')
print 'ITALIANA'
select count(*) from unisys.dbo.news where contains (text, 'ITALIANA')
print 'COLLABORAZIONE'
select count(*) from unisys.dbo.news where contains (text, 'COLLABORAZIONE')
print 'FACILE'
select count(*) from unisys.dbo.news where contains (text, 'FACILE')
print 'AMERICA'
select count(*) from unisys.dbo.news where contains (text, 'AMERICA')
print 'CHIESTO'
select count(*) from unisys.dbo.news where contains (text, 'CHIESTO')
print 'NERO'
select count(*) from unisys.dbo.news where contains (text, 'NERO')
print 'GOVERNO'
select count(*) from unisys.dbo.news where contains (text, 'GOVERNO')
print 'DIFESA'
select count(*) from unisys.dbo.news where contains (text, 'DIFESA')
print 'DECISO'
select count(*) from unisys.dbo.news where contains (text, 'DECISO')
print 'CERCA'
select count(*) from unisys.dbo.news where contains (text, 'CERCA')
print 'PARTITI'
select count(*) from unisys.dbo.news where contains (text, 'PARTITI')
print 'RISPETTO'
select count(*) from unisys.dbo.news where contains (text, 'RISPETTO')
print 'PROVINCIA'
select count(*) from unisys.dbo.news where contains (text, 'PROVINCIA')
print 'SEMBRA'
select count(*) from unisys.dbo.news where contains (text, 'SEMBRA')
print 'CITTADINI'
select count(*) from unisys.dbo.news where contains (text, 'CITTADINI')
print 'INFORMAZIONI'
select count(*) from unisys.dbo.news where contains (text, 'INFORMAZIONI')
print 'PAROLA'
select count(*) from unisys.dbo.news where contains (text, 'PAROLA')
print 'CITT�'
select count(*) from unisys.dbo.news where contains (text, 'CITT�')
print 'NOTTE'
select count(*) from unisys.dbo.news where contains (text, 'NOTTE')
print 'LIRE'
select count(*) from unisys.dbo.news where contains (text, 'LIRE')
print 'MINUTI'
select count(*) from unisys.dbo.news where contains (text, 'MINUTI')
print 'AUTORE'
select count(*) from unisys.dbo.news where contains (text, 'AUTORE')
print 'NECESSIT�'
select count(*) from unisys.dbo.news where contains (text, 'NECESSIT�')
print 'AGOSTO'
select count(*) from unisys.dbo.news where contains (text, 'AGOSTO')
print 'FILM'
select count(*) from unisys.dbo.news where contains (text, 'FILM')
print 'COPPA'
select count(*) from unisys.dbo.news where contains (text, 'COPPA')
print 'BUON'
select count(*) from unisys.dbo.news where contains (text, 'BUON')
print 'PRODUZIONE'
select count(*) from unisys.dbo.news where contains (text, 'PRODUZIONE')
print 'SVILUPPO'
select count(*) from unisys.dbo.news where contains (text, 'SVILUPPO')
print 'FAR�'
select count(*) from unisys.dbo.news where contains (text, 'FAR�')
print 'ACCANTO'
select count(*) from unisys.dbo.news where contains (text, 'ACCANTO')
print 'OPERE'
select count(*) from unisys.dbo.news where contains (text, 'OPERE')
print 'ARRIVARE'
select count(*) from unisys.dbo.news where contains (text, 'ARRIVARE')
print 'DOMANDA'
select count(*) from unisys.dbo.news where contains (text, 'DOMANDA')
print 'OCCHI'
select count(*) from unisys.dbo.news where contains (text, 'OCCHI')
print 'PERSONAGGI'
select count(*) from unisys.dbo.news where contains (text, 'PERSONAGGI')
print 'VANNO'
select count(*) from unisys.dbo.news where contains (text, 'VANNO')
print 'PICCOLA'
select count(*) from unisys.dbo.news where contains (text, 'PICCOLA')
print 'CAMPAGNA'
select count(*) from unisys.dbo.news where contains (text, 'CAMPAGNA')
print 'MOSTRA'
select count(*) from unisys.dbo.news where contains (text, 'MOSTRA')
print 'RISPOSTA'
select count(*) from unisys.dbo.news where contains (text, 'RISPOSTA')
print 'FIDUCIA'
select count(*) from unisys.dbo.news where contains (text, 'FIDUCIA')
print 'RACCONTA'
select count(*) from unisys.dbo.news where contains (text, 'RACCONTA')
print 'SOLUZIONE'
select count(*) from unisys.dbo.news where contains (text, 'SOLUZIONE')
print 'SISTEMA'
select count(*) from unisys.dbo.news where contains (text, 'SISTEMA')
print 'FONDO'
select count(*) from unisys.dbo.news where contains (text, 'FONDO')
print 'GIUDIZIO'
select count(*) from unisys.dbo.news where contains (text, 'GIUDIZIO')
print 'MOGLIE'
select count(*) from unisys.dbo.news where contains (text, 'MOGLIE')
print 'PRIME'
select count(*) from unisys.dbo.news where contains (text, 'PRIME')
print 'LIVELLO'
select count(*) from unisys.dbo.news where contains (text, 'LIVELLO')
print 'GIOVANE'
select count(*) from unisys.dbo.news where contains (text, 'GIOVANE')
print 'CAPO'
select count(*) from unisys.dbo.news where contains (text, 'CAPO')
print 'BIANCO'
select count(*) from unisys.dbo.news where contains (text, 'BIANCO')
print 'VICENDA'
select count(*) from unisys.dbo.news where contains (text, 'VICENDA')
print 'FORZE'
select count(*) from unisys.dbo.news where contains (text, 'FORZE')
print 'PRODOTTO'
select count(*) from unisys.dbo.news where contains (text, 'PRODOTTO')
print 'GIORGIO'
select count(*) from unisys.dbo.news where contains (text, 'GIORGIO')
print 'IMPORTANTE'
select count(*) from unisys.dbo.news where contains (text, 'IMPORTANTE')
print 'RAGAZZI'
select count(*) from unisys.dbo.news where contains (text, 'RAGAZZI')
print 'ANSA'
select count(*) from unisys.dbo.news where contains (text, 'ANSA')
print 'SCORSO'
select count(*) from unisys.dbo.news where contains (text, 'SCORSO')
print 'GUIDA'
select count(*) from unisys.dbo.news where contains (text, 'GUIDA')
print 'RISCHIO'
select count(*) from unisys.dbo.news where contains (text, 'RISCHIO')
print 'EUROPEA'
select count(*) from unisys.dbo.news where contains (text, 'EUROPEA')
print 'GRUPPO'
select count(*) from unisys.dbo.news where contains (text, 'GRUPPO')
print 'CREDO'
select count(*) from unisys.dbo.news where contains (text, 'CREDO')
print 'LEGA'
select count(*) from unisys.dbo.news where contains (text, 'LEGA')
print 'PRESENTE'
select count(*) from unisys.dbo.news where contains (text, 'PRESENTE')
print 'MARCO'
select count(*) from unisys.dbo.news where contains (text, 'MARCO')
print 'ENTRO'
select count(*) from unisys.dbo.news where contains (text, 'ENTRO')
print 'TRATTA'
select count(*) from unisys.dbo.news where contains (text, 'TRATTA')
print 'INIZIATIVA'
select count(*) from unisys.dbo.news where contains (text, 'INIZIATIVA')
print 'ITALIANI'
select count(*) from unisys.dbo.news where contains (text, 'ITALIANI')
print 'FRANCIA'
select count(*) from unisys.dbo.news where contains (text, 'FRANCIA')
print 'GIANNI'
select count(*) from unisys.dbo.news where contains (text, 'GIANNI')
print 'IMPEGNO'
select count(*) from unisys.dbo.news where contains (text, 'IMPEGNO')
print 'GRAN'
select count(*) from unisys.dbo.news where contains (text, 'GRAN')
print 'SPIEGA'
select count(*) from unisys.dbo.news where contains (text, 'SPIEGA')
print 'NOTIZIA'
select count(*) from unisys.dbo.news where contains (text, 'NOTIZIA')
print 'VERR�'
select count(*) from unisys.dbo.news where contains (text, 'VERR�')
print 'PASSO'
select count(*) from unisys.dbo.news where contains (text, 'PASSO')
print 'LOTTA'
select count(*) from unisys.dbo.news where contains (text, 'LOTTA')
print 'SERATA'
select count(*) from unisys.dbo.news where contains (text, 'SERATA')
print 'ACCUSA'
select count(*) from unisys.dbo.news where contains (text, 'ACCUSA')
print 'DIVENTARE'
select count(*) from unisys.dbo.news where contains (text, 'DIVENTARE')
print 'FINALMENTE'
select count(*) from unisys.dbo.news where contains (text, 'FINALMENTE')
print 'FAVORE'
select count(*) from unisys.dbo.news where contains (text, 'FAVORE')
print 'INCHIESTA'
select count(*) from unisys.dbo.news where contains (text, 'INCHIESTA')
print 'PENSA'
select count(*) from unisys.dbo.news where contains (text, 'PENSA')
print 'GARA'
select count(*) from unisys.dbo.news where contains (text, 'GARA')
print 'PRESENTA'
select count(*) from unisys.dbo.news where contains (text, 'PRESENTA')
print 'RICERCA'
select count(*) from unisys.dbo.news where contains (text, 'RICERCA')
print 'VOLTE'
select count(*) from unisys.dbo.news where contains (text, 'VOLTE')
print 'SQUADRA'
select count(*) from unisys.dbo.news where contains (text, 'SQUADRA')
print 'RISULTATO'
select count(*) from unisys.dbo.news where contains (text, 'RISULTATO')
print 'CHIAMA'
select count(*) from unisys.dbo.news where contains (text, 'CHIAMA')
print 'LUNED�'
select count(*) from unisys.dbo.news where contains (text, 'LUNED�')
print 'CONFERMA'
select count(*) from unisys.dbo.news where contains (text, 'CONFERMA')
print 'ORDINE'
select count(*) from unisys.dbo.news where contains (text, 'ORDINE')
print 'GIORNALI'
select count(*) from unisys.dbo.news where contains (text, 'GIORNALI')
print 'NECESSARIO'
select count(*) from unisys.dbo.news where contains (text, 'NECESSARIO')
print 'ENTRARE'
select count(*) from unisys.dbo.news where contains (text, 'ENTRARE')
print 'TEMPI'
select count(*) from unisys.dbo.news where contains (text, 'TEMPI')
print 'BERLUSCONI'
select count(*) from unisys.dbo.news where contains (text, 'BERLUSCONI')
print 'QUEST'
select count(*) from unisys.dbo.news where contains (text, 'QUEST')
print 'POLITICHE'
select count(*) from unisys.dbo.news where contains (text, 'POLITICHE')
print 'MILIONI'
select count(*) from unisys.dbo.news where contains (text, 'MILIONI')
print 'MARIO'
select count(*) from unisys.dbo.news where contains (text, 'MARIO')
print 'SOLDI'
select count(*) from unisys.dbo.news where contains (text, 'SOLDI')
print 'SEGRETARIO'
select count(*) from unisys.dbo.news where contains (text, 'SEGRETARIO')
print 'PRESENZA'
select count(*) from unisys.dbo.news where contains (text, 'PRESENZA')
print 'TITOLO'
select count(*) from unisys.dbo.news where contains (text, 'TITOLO')
print 'SCRIVE'
select count(*) from unisys.dbo.news where contains (text, 'SCRIVE')
print 'OCCASIONE'
select count(*) from unisys.dbo.news where contains (text, 'OCCASIONE')
print 'ANNUNCIATO'
select count(*) from unisys.dbo.news where contains (text, 'ANNUNCIATO')
print 'ANDATO'
select count(*) from unisys.dbo.news where contains (text, 'ANDATO')
print 'POLITICO'
select count(*) from unisys.dbo.news where contains (text, 'POLITICO')
print 'ARIA'
select count(*) from unisys.dbo.news where contains (text, 'ARIA')
print 'PERSONA'
select count(*) from unisys.dbo.news where contains (text, 'PERSONA')
print 'VENERD�'
select count(*) from unisys.dbo.news where contains (text, 'VENERD�')
print 'MERCOLED�'
select count(*) from unisys.dbo.news where contains (text, 'MERCOLED�')
print 'AZIONE'
select count(*) from unisys.dbo.news where contains (text, 'AZIONE')
print 'LUGLIO'
select count(*) from unisys.dbo.news where contains (text, 'LUGLIO')
print 'MALE'
select count(*) from unisys.dbo.news where contains (text, 'MALE')
print 'CHIEDE'
select count(*) from unisys.dbo.news where contains (text, 'CHIEDE')
print 'PROGRAMMA'
select count(*) from unisys.dbo.news where contains (text, 'PROGRAMMA')
print 'NATURALMENTE'
select count(*) from unisys.dbo.news where contains (text, 'NATURALMENTE')
print 'SIGNIFICA'
select count(*) from unisys.dbo.news where contains (text, 'SIGNIFICA')
print 'LONDRA'
select count(*) from unisys.dbo.news where contains (text, 'LONDRA')
print 'SOPRATTUTTO'
select count(*) from unisys.dbo.news where contains (text, 'SOPRATTUTTO')
print 'PREVEDE'
select count(*) from unisys.dbo.news where contains (text, 'PREVEDE')
print 'SPETTACOLO'
select count(*) from unisys.dbo.news where contains (text, 'SPETTACOLO')
print 'CHIESA'
select count(*) from unisys.dbo.news where contains (text, 'CHIESA')
print 'LETTERA'
select count(*) from unisys.dbo.news where contains (text, 'LETTERA')
print 'AVVOCATO'
select count(*) from unisys.dbo.news where contains (text, 'AVVOCATO')
print 'GIOVANNI'
select count(*) from unisys.dbo.news where contains (text, 'GIOVANNI')
print 'ASSOCIAZIONE'
select count(*) from unisys.dbo.news where contains (text, 'ASSOCIAZIONE')
print 'GENERE'
select count(*) from unisys.dbo.news where contains (text, 'GENERE')
print 'MEDIA'
select count(*) from unisys.dbo.news where contains (text, 'MEDIA')
print 'BREVE'
select count(*) from unisys.dbo.news where contains (text, 'BREVE')
print 'BILANCIO'
select count(*) from unisys.dbo.news where contains (text, 'BILANCIO')
print 'VEDE'
select count(*) from unisys.dbo.news where contains (text, 'VEDE')
print 'FORTUNA'
select count(*) from unisys.dbo.news where contains (text, 'FORTUNA')
print 'INVIATO'
select count(*) from unisys.dbo.news where contains (text, 'INVIATO')
print 'SITUAZIONE'
select count(*) from unisys.dbo.news where contains (text, 'SITUAZIONE')
print 'PUBBLICA'
select count(*) from unisys.dbo.news where contains (text, 'PUBBLICA')
print 'SABATO'
select count(*) from unisys.dbo.news where contains (text, 'SABATO')
print 'POLITICA'
select count(*) from unisys.dbo.news where contains (text, 'POLITICA')
print 'ULTIMI'
select count(*) from unisys.dbo.news where contains (text, 'ULTIMI')
print 'INTERESSE'
select count(*) from unisys.dbo.news where contains (text, 'INTERESSE')
print 'BELLA'
select count(*) from unisys.dbo.news where contains (text, 'BELLA')
print 'TERZA'
select count(*) from unisys.dbo.news where contains (text, 'TERZA')
print 'DIRITTO'
select count(*) from unisys.dbo.news where contains (text, 'DIRITTO')
print 'YORK'
select count(*) from unisys.dbo.news where contains (text, 'YORK')
print 'RICORDA'
select count(*) from unisys.dbo.news where contains (text, 'RICORDA')
print 'POMERIGGIO'
select count(*) from unisys.dbo.news where contains (text, 'POMERIGGIO')
print 'VENGONO'
select count(*) from unisys.dbo.news where contains (text, 'VENGONO')
print 'LEGGE'
select count(*) from unisys.dbo.news where contains (text, 'LEGGE')
print 'UOMINI'
select count(*) from unisys.dbo.news where contains (text, 'UOMINI')
print 'CRISI'
select count(*) from unisys.dbo.news where contains (text, 'CRISI')
print 'MORTO'
select count(*) from unisys.dbo.news where contains (text, 'MORTO')
print 'CULTURA'
select count(*) from unisys.dbo.news where contains (text, 'CULTURA')
print 'GIOVED�'
select count(*) from unisys.dbo.news where contains (text, 'GIOVED�')
print 'ACQUA'
select count(*) from unisys.dbo.news where contains (text, 'ACQUA')
print 'DOMANI'
select count(*) from unisys.dbo.news where contains (text, 'DOMANI')
print 'RESPONSABILE'
select count(*) from unisys.dbo.news where contains (text, 'RESPONSABILE')
print 'EFFETTI'
select count(*) from unisys.dbo.news where contains (text, 'EFFETTI')
print 'SOLTANTO'
select count(*) from unisys.dbo.news where contains (text, 'SOLTANTO')
print 'SOLA'
select count(*) from unisys.dbo.news where contains (text, 'SOLA')
print 'MONDIALE'
select count(*) from unisys.dbo.news where contains (text, 'MONDIALE')
print 'CONSIGLIO'
select count(*) from unisys.dbo.news where contains (text, 'CONSIGLIO')
print 'RAGIONE'
select count(*) from unisys.dbo.news where contains (text, 'RAGIONE')
print 'AGGIUNGE'
select count(*) from unisys.dbo.news where contains (text, 'AGGIUNGE')
print 'TESTA'
select count(*) from unisys.dbo.news where contains (text, 'TESTA')
print 'GUERRA'
select count(*) from unisys.dbo.news where contains (text, 'GUERRA')
print 'GIOVANI'
select count(*) from unisys.dbo.news where contains (text, 'GIOVANI')
print 'ROBERTO'
select count(*) from unisys.dbo.news where contains (text, 'ROBERTO')
print 'DISPOSIZIONE'
select count(*) from unisys.dbo.news where contains (text, 'DISPOSIZIONE')
print 'BATTAGLIA'
select count(*) from unisys.dbo.news where contains (text, 'BATTAGLIA')
print 'ARTE'
select count(*) from unisys.dbo.news where contains (text, 'ARTE')
print 'CARABINIERI'
select count(*) from unisys.dbo.news where contains (text, 'CARABINIERI')
print 'PERSINO'
select count(*) from unisys.dbo.news where contains (text, 'PERSINO')
print 'RAPPORTO'
select count(*) from unisys.dbo.news where contains (text, 'RAPPORTO')
print 'POSSIBILE'
select count(*) from unisys.dbo.news where contains (text, 'POSSIBILE')
print 'SINISTRA'
select count(*) from unisys.dbo.news where contains (text, 'SINISTRA')
print 'METRI'
select count(*) from unisys.dbo.news where contains (text, 'METRI')
print 'NUMERO'
select count(*) from unisys.dbo.news where contains (text, 'NUMERO')
print 'CAMPIONATO'
select count(*) from unisys.dbo.news where contains (text, 'CAMPIONATO')
print 'SICUREZZA'
select count(*) from unisys.dbo.news where contains (text, 'SICUREZZA')
print 'AMORE'
select count(*) from unisys.dbo.news where contains (text, 'AMORE')
print 'MUSICA'
select count(*) from unisys.dbo.news where contains (text, 'MUSICA')
print 'PARE'
select count(*) from unisys.dbo.news where contains (text, 'PARE')
print 'MINISTERO'
select count(*) from unisys.dbo.news where contains (text, 'MINISTERO')
print 'RISULTATI'
select count(*) from unisys.dbo.news where contains (text, 'RISULTATI')
print 'CARTA'
select count(*) from unisys.dbo.news where contains (text, 'CARTA')
print 'GIUSTIZIA'
select count(*) from unisys.dbo.news where contains (text, 'GIUSTIZIA')
print 'PROSSIMO'
select count(*) from unisys.dbo.news where contains (text, 'PROSSIMO')
print 'NOVIT�'
select count(*) from unisys.dbo.news where contains (text, 'NOVIT�')
print 'FRANCESE'
select count(*) from unisys.dbo.news where contains (text, 'FRANCESE')
print 'PUBBLICO'
select count(*) from unisys.dbo.news where contains (text, 'PUBBLICO')
print 'DIRE'
select count(*) from unisys.dbo.news where contains (text, 'DIRE')
print 'UNIVERSIT�'
select count(*) from unisys.dbo.news where contains (text, 'UNIVERSIT�')
print 'INIZIO'
select count(*) from unisys.dbo.news where contains (text, 'INIZIO')
print 'UNICO'
select count(*) from unisys.dbo.news where contains (text, 'UNICO')
print 'GESTIONE'
select count(*) from unisys.dbo.news where contains (text, 'GESTIONE')
print 'METTE'
select count(*) from unisys.dbo.news where contains (text, 'METTE')
print 'DIREZIONE'
select count(*) from unisys.dbo.news where contains (text, 'DIREZIONE')
print 'ANDARE'
select count(*) from unisys.dbo.news where contains (text, 'ANDARE')
print 'DIVERSI'
select count(*) from unisys.dbo.news where contains (text, 'DIVERSI')
print 'SOLITO'
select count(*) from unisys.dbo.news where contains (text, 'SOLITO')
print 'PUBBLICI'
select count(*) from unisys.dbo.news where contains (text, 'PUBBLICI')
print 'ASSESSORE'
select count(*) from unisys.dbo.news where contains (text, 'ASSESSORE')
print 'AREA'
select count(*) from unisys.dbo.news where contains (text, 'AREA')
print 'PREVISTO'
select count(*) from unisys.dbo.news where contains (text, 'PREVISTO')
print 'SETTIMANA'
select count(*) from unisys.dbo.news where contains (text, 'SETTIMANA')
print 'INOLTRE'
select count(*) from unisys.dbo.news where contains (text, 'INOLTRE')
print 'PIEDI'
select count(*) from unisys.dbo.news where contains (text, 'PIEDI')
print 'STAMPA'
select count(*) from unisys.dbo.news where contains (text, 'STAMPA')
print 'CASI'
select count(*) from unisys.dbo.news where contains (text, 'CASI')
print 'CIVILE'
select count(*) from unisys.dbo.news where contains (text, 'CIVILE')
print 'RUOLO'
select count(*) from unisys.dbo.news where contains (text, 'RUOLO')
print 'REGIONALE'
select count(*) from unisys.dbo.news where contains (text, 'REGIONALE')
print 'MET�'
select count(*) from unisys.dbo.news where contains (text, 'MET�')
print 'IDEA'
select count(*) from unisys.dbo.news where contains (text, 'IDEA')
print 'FOTO'
select count(*) from unisys.dbo.news where contains (text, 'FOTO')
print 'ESTATE'
select count(*) from unisys.dbo.news where contains (text, 'ESTATE')
print 'BASE'
select count(*) from unisys.dbo.news where contains (text, 'BASE')
print 'PROVA'
select count(*) from unisys.dbo.news where contains (text, 'PROVA')
print 'MESI'
select count(*) from unisys.dbo.news where contains (text, 'MESI')
print 'POLIZIA'
select count(*) from unisys.dbo.news where contains (text, 'POLIZIA')
print 'ARRIVATO'
select count(*) from unisys.dbo.news where contains (text, 'ARRIVATO')
print 'ALBERTO'
select count(*) from unisys.dbo.news where contains (text, 'ALBERTO')
print 'DESTRA'
select count(*) from unisys.dbo.news where contains (text, 'DESTRA')
print 'NATO'
select count(*) from unisys.dbo.news where contains (text, 'NATO')
print 'ALTA'
select count(*) from unisys.dbo.news where contains (text, 'ALTA')
print 'MAGGIOR'
select count(*) from unisys.dbo.news where contains (text, 'MAGGIOR')
print 'CENTRO'
select count(*) from unisys.dbo.news where contains (text, 'CENTRO')
print 'VISTA'
select count(*) from unisys.dbo.news where contains (text, 'VISTA')
print 'PROCESSO'
select count(*) from unisys.dbo.news where contains (text, 'PROCESSO')
print 'CONTO'
select count(*) from unisys.dbo.news where contains (text, 'CONTO')
print 'GRADO'
select count(*) from unisys.dbo.news where contains (text, 'GRADO')
print 'FUTURO'
select count(*) from unisys.dbo.news where contains (text, 'FUTURO')
print 'DICHIARATO'
select count(*) from unisys.dbo.news where contains (text, 'DICHIARATO')
print 'TROVA'
select count(*) from unisys.dbo.news where contains (text, 'TROVA')
print 'REPUBBLICA'
select count(*) from unisys.dbo.news where contains (text, 'REPUBBLICA')
print 'INFINE'
select count(*) from unisys.dbo.news where contains (text, 'INFINE')
print 'VERO'
select count(*) from unisys.dbo.news where contains (text, 'VERO')
print 'COSE'
select count(*) from unisys.dbo.news where contains (text, 'COSE')
print 'PORTARE'
select count(*) from unisys.dbo.news where contains (text, 'PORTARE')
print 'DIVENTA'
select count(*) from unisys.dbo.news where contains (text, 'DIVENTA')
print 'MODO'
select count(*) from unisys.dbo.news where contains (text, 'MODO')
print 'OSPEDALE'
select count(*) from unisys.dbo.news where contains (text, 'OSPEDALE')
print 'GIRO'
select count(*) from unisys.dbo.news where contains (text, 'GIRO')
print 'RIMASTO'
select count(*) from unisys.dbo.news where contains (text, 'RIMASTO')
print 'CONFRONTI'
select count(*) from unisys.dbo.news where contains (text, 'CONFRONTI')
print 'NUOVI'
select count(*) from unisys.dbo.news where contains (text, 'NUOVI')
print 'DIRETTO'
select count(*) from unisys.dbo.news where contains (text, 'DIRETTO')
print 'NOMI'
select count(*) from unisys.dbo.news where contains (text, 'NOMI')
print 'PRESO'
select count(*) from unisys.dbo.news where contains (text, 'PRESO')
print 'ROMANO'
select count(*) from unisys.dbo.news where contains (text, 'ROMANO')
print 'COSTO'
select count(*) from unisys.dbo.news where contains (text, 'COSTO')
print 'GIUNTA'
select count(*) from unisys.dbo.news where contains (text, 'GIUNTA')
print 'APRILE'
select count(*) from unisys.dbo.news where contains (text, 'APRILE')
print 'MESSO'
select count(*) from unisys.dbo.news where contains (text, 'MESSO')
print 'INTERVENTO'
select count(*) from unisys.dbo.news where contains (text, 'INTERVENTO')
print 'RITORNO'
select count(*) from unisys.dbo.news where contains (text, 'RITORNO')
print 'ORMAI'
select count(*) from unisys.dbo.news where contains (text, 'ORMAI')
print 'DATI'
select count(*) from unisys.dbo.news where contains (text, 'DATI')
print 'PROBABILMENTE'
select count(*) from unisys.dbo.news where contains (text, 'PROBABILMENTE')
print 'PARTITO'
select count(*) from unisys.dbo.news where contains (text, 'PARTITO')
print 'NOVEMBRE'
select count(*) from unisys.dbo.news where contains (text, 'NOVEMBRE')
print 'VERDE'
select count(*) from unisys.dbo.news where contains (text, 'VERDE')
print 'CURA'
select count(*) from unisys.dbo.news where contains (text, 'CURA')
print 'GENTE'
select count(*) from unisys.dbo.news where contains (text, 'GENTE')
print 'AMERICANO'
select count(*) from unisys.dbo.news where contains (text, 'AMERICANO')
print 'PARLATO'
select count(*) from unisys.dbo.news where contains (text, 'PARLATO')
print 'CONTINUA'
select count(*) from unisys.dbo.news where contains (text, 'CONTINUA')
print 'MINISTRO'
select count(*) from unisys.dbo.news where contains (text, 'MINISTRO')
print 'PACE'
select count(*) from unisys.dbo.news where contains (text, 'PACE')
print 'UOMO'
select count(*) from unisys.dbo.news where contains (text, 'UOMO')
print 'MOVIMENTO'
select count(*) from unisys.dbo.news where contains (text, 'MOVIMENTO')
print 'PASSATO'
select count(*) from unisys.dbo.news where contains (text, 'PASSATO')
print 'FRANCO'
select count(*) from unisys.dbo.news where contains (text, 'FRANCO')
print 'SALA'
select count(*) from unisys.dbo.news where contains (text, 'SALA')
print 'MAGGIO'
select count(*) from unisys.dbo.news where contains (text, 'MAGGIO')
print 'DECISIONE'
select count(*) from unisys.dbo.news where contains (text, 'DECISIONE')
print 'PALAZZO'
select count(*) from unisys.dbo.news where contains (text, 'PALAZZO')
print 'LAVORARE'
select count(*) from unisys.dbo.news where contains (text, 'LAVORARE')
print 'VIAGGIO'
select count(*) from unisys.dbo.news where contains (text, 'VIAGGIO')
print 'RAPPORTI'
select count(*) from unisys.dbo.news where contains (text, 'RAPPORTI')
print 'DIRETTORE'
select count(*) from unisys.dbo.news where contains (text, 'DIRETTORE')
print 'FATTA'
select count(*) from unisys.dbo.news where contains (text, 'FATTA')
print 'GIUGNO'
select count(*) from unisys.dbo.news where contains (text, 'GIUGNO')
print 'SENSO'
select count(*) from unisys.dbo.news where contains (text, 'SENSO')
print 'PASSARE'
select count(*) from unisys.dbo.news where contains (text, 'PASSARE')
print 'QUELL'
select count(*) from unisys.dbo.news where contains (text, 'QUELL')
print 'ADESSO'
select count(*) from unisys.dbo.news where contains (text, 'ADESSO')
print 'PROBLEMI'
select count(*) from unisys.dbo.news where contains (text, 'PROBLEMI')
print 'ATTRAVERSO'
select count(*) from unisys.dbo.news where contains (text, 'ATTRAVERSO')
print 'MEZZO'
select count(*) from unisys.dbo.news where contains (text, 'MEZZO')
print 'TORNARE'
select count(*) from unisys.dbo.news where contains (text, 'TORNARE')
print 'NAZIONALE'
select count(*) from unisys.dbo.news where contains (text, 'NAZIONALE')
print 'BUONA'
select count(*) from unisys.dbo.news where contains (text, 'BUONA')
print 'SETTORE'
select count(*) from unisys.dbo.news where contains (text, 'SETTORE')
print 'PAESE'
select count(*) from unisys.dbo.news where contains (text, 'PAESE')
print 'OBIETTIVO'
select count(*) from unisys.dbo.news where contains (text, 'OBIETTIVO')
print 'ARRIVO'
select count(*) from unisys.dbo.news where contains (text, 'ARRIVO')
print 'LONTANO'
select count(*) from unisys.dbo.news where contains (text, 'LONTANO')
print 'EPOCA'
select count(*) from unisys.dbo.news where contains (text, 'EPOCA')
print 'POPOLARE'
select count(*) from unisys.dbo.news where contains (text, 'POPOLARE')
print 'MONDO'
select count(*) from unisys.dbo.news where contains (text, 'MONDO')
print 'PROPOSTA'
select count(*) from unisys.dbo.news where contains (text, 'PROPOSTA')
print 'ANDATA'
select count(*) from unisys.dbo.news where contains (text, 'ANDATA')
print 'VECCHIO'
select count(*) from unisys.dbo.news where contains (text, 'VECCHIO')
print 'PAURA'
select count(*) from unisys.dbo.news where contains (text, 'PAURA')
print 'PERSO'
select count(*) from unisys.dbo.news where contains (text, 'PERSO')
print 'MILIARDI'
select count(*) from unisys.dbo.news where contains (text, 'MILIARDI')
print 'PIERO'
select count(*) from unisys.dbo.news where contains (text, 'PIERO')
print 'SINDACO'
select count(*) from unisys.dbo.news where contains (text, 'SINDACO')
print 'GRAVE'
select count(*) from unisys.dbo.news where contains (text, 'GRAVE')
print 'MARIA'
select count(*) from unisys.dbo.news where contains (text, 'MARIA')
print 'SCRITTO'
select count(*) from unisys.dbo.news where contains (text, 'SCRITTO')
print 'IMPORTANTI'
select count(*) from unisys.dbo.news where contains (text, 'IMPORTANTI')
print 'VINTO'
select count(*) from unisys.dbo.news where contains (text, 'VINTO')
print 'GIUSEPPE'
select count(*) from unisys.dbo.news where contains (text, 'GIUSEPPE')
print 'AMICO'
select count(*) from unisys.dbo.news where contains (text, 'AMICO')
print 'RESTO'
select count(*) from unisys.dbo.news where contains (text, 'RESTO')
print 'DICONO'
select count(*) from unisys.dbo.news where contains (text, 'DICONO')
print 'ULTIME'
select count(*) from unisys.dbo.news where contains (text, 'ULTIME')
print 'CAPITALE'
select count(*) from unisys.dbo.news where contains (text, 'CAPITALE')
print 'VERA'
select count(*) from unisys.dbo.news where contains (text, 'VERA')
print 'ADDIRITTURA'
select count(*) from unisys.dbo.news where contains (text, 'ADDIRITTURA')
print 'TERMINE'
select count(*) from unisys.dbo.news where contains (text, 'TERMINE')
print 'PIUTTOSTO'
select count(*) from unisys.dbo.news where contains (text, 'PIUTTOSTO')
print 'SERA'
select count(*) from unisys.dbo.news where contains (text, 'SERA')
print 'TROVARE'
select count(*) from unisys.dbo.news where contains (text, 'TROVARE')
print 'AZIENDA'
select count(*) from unisys.dbo.news where contains (text, 'AZIENDA')
print 'IMMAGINE'
select count(*) from unisys.dbo.news where contains (text, 'IMMAGINE')
print 'DAVVERO'
select count(*) from unisys.dbo.news where contains (text, 'DAVVERO')
print 'PREMIO'
select count(*) from unisys.dbo.news where contains (text, 'PREMIO')
print 'SECOLO'
select count(*) from unisys.dbo.news where contains (text, 'SECOLO')
print 'UFFICIALE'
select count(*) from unisys.dbo.news where contains (text, 'UFFICIALE')
print 'BANCA'
select count(*) from unisys.dbo.news where contains (text, 'BANCA')
print 'VOCE'
select count(*) from unisys.dbo.news where contains (text, 'VOCE')
print 'PORTATO'
select count(*) from unisys.dbo.news where contains (text, 'PORTATO')
print 'REGIONE'
select count(*) from unisys.dbo.news where contains (text, 'REGIONE')
print 'SCUOLA'
select count(*) from unisys.dbo.news where contains (text, 'SCUOLA')
print 'RIFERIMENTO'
select count(*) from unisys.dbo.news where contains (text, 'RIFERIMENTO')
print 'GIORNATA'
select count(*) from unisys.dbo.news where contains (text, 'GIORNATA')
print 'GIUSTO'
select count(*) from unisys.dbo.news where contains (text, 'GIUSTO')
print 'APERTA'
select count(*) from unisys.dbo.news where contains (text, 'APERTA')
print 'NORD'
select count(*) from unisys.dbo.news where contains (text, 'NORD')
print 'INTANTO'
select count(*) from unisys.dbo.news where contains (text, 'INTANTO')
print 'LINEA'
select count(*) from unisys.dbo.news where contains (text, 'LINEA')
print 'INTERNAZIONALE'
select count(*) from unisys.dbo.news where contains (text, 'INTERNAZIONALE')
print 'FATTI'
select count(*) from unisys.dbo.news where contains (text, 'FATTI')
print 'PAROLE'
select count(*) from unisys.dbo.news where contains (text, 'PAROLE')
print 'SETTEMBRE'
select count(*) from unisys.dbo.news where contains (text, 'SETTEMBRE')
print 'TIPO'
select count(*) from unisys.dbo.news where contains (text, 'TIPO')
print 'LUIGI'
select count(*) from unisys.dbo.news where contains (text, 'LUIGI')
print 'PERDERE'
select count(*) from unisys.dbo.news where contains (text, 'PERDERE')
print 'CONTRARIO'
select count(*) from unisys.dbo.news where contains (text, 'CONTRARIO')
print 'LIBRO'
select count(*) from unisys.dbo.news where contains (text, 'LIBRO')
print 'DATO'
select count(*) from unisys.dbo.news where contains (text, 'DATO')
print 'ELEZIONI'
select count(*) from unisys.dbo.news where contains (text, 'ELEZIONI')
print 'FESTA'
select count(*) from unisys.dbo.news where contains (text, 'FESTA')
print 'PRESENTATO'
select count(*) from unisys.dbo.news where contains (text, 'PRESENTATO')
print 'CUORE'
select count(*) from unisys.dbo.news where contains (text, 'CUORE')
print 'INCONTRO'
select count(*) from unisys.dbo.news where contains (text, 'INCONTRO')
print 'SETTIMANE'
select count(*) from unisys.dbo.news where contains (text, 'SETTIMANE')
print 'EVITARE'
select count(*) from unisys.dbo.news where contains (text, 'EVITARE')
print 'GENERALE'
select count(*) from unisys.dbo.news where contains (text, 'GENERALE')
print 'RIGUARDA'
select count(*) from unisys.dbo.news where contains (text, 'RIGUARDA')
print 'STORICO'
select count(*) from unisys.dbo.news where contains (text, 'STORICO')
print 'PAGARE'
select count(*) from unisys.dbo.news where contains (text, 'PAGARE')
print 'CORPO'
select count(*) from unisys.dbo.news where contains (text, 'CORPO')
print 'PIEMONTE'
select count(*) from unisys.dbo.news where contains (text, 'PIEMONTE')
print 'FIGLIO'
select count(*) from unisys.dbo.news where contains (text, 'FIGLIO')
print 'STANNO'
select count(*) from unisys.dbo.news where contains (text, 'STANNO')
print 'SPESSO'
select count(*) from unisys.dbo.news where contains (text, 'SPESSO')
print 'PENSARE'
select count(*) from unisys.dbo.news where contains (text, 'PENSARE')
print 'STORIA'
select count(*) from unisys.dbo.news where contains (text, 'STORIA')
print 'SERVIZIO'
select count(*) from unisys.dbo.news where contains (text, 'SERVIZIO')
print 'PAESI'
select count(*) from unisys.dbo.news where contains (text, 'PAESI')
print 'POSTO'
select count(*) from unisys.dbo.news where contains (text, 'POSTO')
print 'TEATRO'
select count(*) from unisys.dbo.news where contains (text, 'TEATRO')
print 'DIFFICILE'
select count(*) from unisys.dbo.news where contains (text, 'DIFFICILE')
print 'VIVERE'
select count(*) from unisys.dbo.news where contains (text, 'VIVERE')
