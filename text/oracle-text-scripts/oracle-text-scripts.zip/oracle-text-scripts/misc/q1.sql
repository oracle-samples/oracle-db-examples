select text from xmltest where contains (text,
'Schuh inpath (//name[@lang="de\-de"])')>0
/
