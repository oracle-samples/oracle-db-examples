This directory is a mess of quick scripts.
It has been left here in the hope that someone looking for a specific feature might find it with a grep on this folder
