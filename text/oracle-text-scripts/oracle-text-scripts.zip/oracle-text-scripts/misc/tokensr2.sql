print 'SOTTO'
select count(*) from unisys.dbo.news where contains (text, 'SOTTO')
print 'OPPURE'
select count(*) from unisys.dbo.news where contains (text, 'OPPURE')
print 'EVITARE'
select count(*) from unisys.dbo.news where contains (text, 'EVITARE')
print 'FINALE'
select count(*) from unisys.dbo.news where contains (text, 'FINALE')
print 'LOTTA'
select count(*) from unisys.dbo.news where contains (text, 'LOTTA')
print 'ALLO'
select count(*) from unisys.dbo.news where contains (text, 'ALLO')
print 'YORK'
select count(*) from unisys.dbo.news where contains (text, 'YORK')
print 'MASSIMO'
select count(*) from unisys.dbo.news where contains (text, 'MASSIMO')
print 'PROSSIMO'
select count(*) from unisys.dbo.news where contains (text, 'PROSSIMO')
print 'FRANCESE'
select count(*) from unisys.dbo.news where contains (text, 'FRANCESE')
print 'POSSONO'
select count(*) from unisys.dbo.news where contains (text, 'POSSONO')
print 'ISTITUTO'
select count(*) from unisys.dbo.news where contains (text, 'ISTITUTO')
print 'ORMAI'
select count(*) from unisys.dbo.news where contains (text, 'ORMAI')
print 'CAPIRE'
select count(*) from unisys.dbo.news where contains (text, 'CAPIRE')
print 'ALTO'
select count(*) from unisys.dbo.news where contains (text, 'ALTO')
print 'FINITO'
select count(*) from unisys.dbo.news where contains (text, 'FINITO')
print 'MERCATO'
select count(*) from unisys.dbo.news where contains (text, 'MERCATO')
print 'PRESO'
select count(*) from unisys.dbo.news where contains (text, 'PRESO')
print 'CINEMA'
select count(*) from unisys.dbo.news where contains (text, 'CINEMA')
print 'PICCOLO'
select count(*) from unisys.dbo.news where contains (text, 'PICCOLO')
print 'GIUDIZIO'
select count(*) from unisys.dbo.news where contains (text, 'GIUDIZIO')
print 'ESEMPIO'
select count(*) from unisys.dbo.news where contains (text, 'ESEMPIO')
print 'FRANCIA'
select count(*) from unisys.dbo.news where contains (text, 'FRANCIA')
print 'CENTO'
select count(*) from unisys.dbo.news where contains (text, 'CENTO')
print 'FESTA'
select count(*) from unisys.dbo.news where contains (text, 'FESTA')
print 'FORZE'
select count(*) from unisys.dbo.news where contains (text, 'FORZE')
print 'PRIMI'
select count(*) from unisys.dbo.news where contains (text, 'PRIMI')
print 'CIRCA'
select count(*) from unisys.dbo.news where contains (text, 'CIRCA')
print 'STATE'
select count(*) from unisys.dbo.news where contains (text, 'STATE')
print 'AZIONE'
select count(*) from unisys.dbo.news where contains (text, 'AZIONE')
print 'AMERICANO'
select count(*) from unisys.dbo.news where contains (text, 'AMERICANO')
print 'FRANCO'
select count(*) from unisys.dbo.news where contains (text, 'FRANCO')
print 'TROVA'
select count(*) from unisys.dbo.news where contains (text, 'TROVA')
print 'UNIONE'
select count(*) from unisys.dbo.news where contains (text, 'UNIONE')
print 'PRIME'
select count(*) from unisys.dbo.news where contains (text, 'PRIME')
print 'PERSONAGGI'
select count(*) from unisys.dbo.news where contains (text, 'PERSONAGGI')
print 'COSTO'
select count(*) from unisys.dbo.news where contains (text, 'COSTO')
print 'GIORNO'
select count(*) from unisys.dbo.news where contains (text, 'GIORNO')
print 'TESTA'
select count(*) from unisys.dbo.news where contains (text, 'TESTA')
print 'COSE'
select count(*) from unisys.dbo.news where contains (text, 'COSE')
print 'BAMBINI'
select count(*) from unisys.dbo.news where contains (text, 'BAMBINI')
print 'SEMBRA'
select count(*) from unisys.dbo.news where contains (text, 'SEMBRA')
print 'PIEDI'
select count(*) from unisys.dbo.news where contains (text, 'PIEDI')
print 'TEMPI'
select count(*) from unisys.dbo.news where contains (text, 'TEMPI')
print 'COSTA'
select count(*) from unisys.dbo.news where contains (text, 'COSTA')
print 'MERCOLED�'
select count(*) from unisys.dbo.news where contains (text, 'MERCOLED�')
print 'PRODUZIONE'
select count(*) from unisys.dbo.news where contains (text, 'PRODUZIONE')
print 'LETTERA'
select count(*) from unisys.dbo.news where contains (text, 'LETTERA')
print 'POTR�'
select count(*) from unisys.dbo.news where contains (text, 'POTR�')
print 'VERR�'
select count(*) from unisys.dbo.news where contains (text, 'VERR�')
print 'REGIONALE'
select count(*) from unisys.dbo.news where contains (text, 'REGIONALE')
print 'GRUPPO'
select count(*) from unisys.dbo.news where contains (text, 'GRUPPO')
print 'AREA'
select count(*) from unisys.dbo.news where contains (text, 'AREA')
print 'TERMINE'
select count(*) from unisys.dbo.news where contains (text, 'TERMINE')
print 'ULTIMO'
select count(*) from unisys.dbo.news where contains (text, 'ULTIMO')
print 'COLPO'
select count(*) from unisys.dbo.news where contains (text, 'COLPO')
print 'STESSA'
select count(*) from unisys.dbo.news where contains (text, 'STESSA')
print 'VICENDA'
select count(*) from unisys.dbo.news where contains (text, 'VICENDA')
print 'MANO'
select count(*) from unisys.dbo.news where contains (text, 'MANO')
print 'FRANCESCO'
select count(*) from unisys.dbo.news where contains (text, 'FRANCESCO')
print 'BRUNO'
select count(*) from unisys.dbo.news where contains (text, 'BRUNO')
print 'AMBIENTE'
select count(*) from unisys.dbo.news where contains (text, 'AMBIENTE')
print 'RISPETTO'
select count(*) from unisys.dbo.news where contains (text, 'RISPETTO')
print 'POCHI'
select count(*) from unisys.dbo.news where contains (text, 'POCHI')
print 'EPOCA'
select count(*) from unisys.dbo.news where contains (text, 'EPOCA')
print 'GRAVE'
select count(*) from unisys.dbo.news where contains (text, 'GRAVE')
print 'ANDATA'
select count(*) from unisys.dbo.news where contains (text, 'ANDATA')
print 'RAPPORTI'
select count(*) from unisys.dbo.news where contains (text, 'RAPPORTI')
print 'MESI'
select count(*) from unisys.dbo.news where contains (text, 'MESI')
print 'ULTIMA'
select count(*) from unisys.dbo.news where contains (text, 'ULTIMA')
print 'MINISTERO'
select count(*) from unisys.dbo.news where contains (text, 'MINISTERO')
print 'OTTENERE'
select count(*) from unisys.dbo.news where contains (text, 'OTTENERE')
print 'MOSTRA'
select count(*) from unisys.dbo.news where contains (text, 'MOSTRA')
print 'RISPOSTA'
select count(*) from unisys.dbo.news where contains (text, 'RISPOSTA')
print 'NOSTRA'
select count(*) from unisys.dbo.news where contains (text, 'NOSTRA')
print 'NOMI'
select count(*) from unisys.dbo.news where contains (text, 'NOMI')
print 'QUELLI'
select count(*) from unisys.dbo.news where contains (text, 'QUELLI')
print 'ALTRE'
select count(*) from unisys.dbo.news where contains (text, 'ALTRE')
print 'OBIETTIVO'
select count(*) from unisys.dbo.news where contains (text, 'OBIETTIVO')
print 'VERSO'
select count(*) from unisys.dbo.news where contains (text, 'VERSO')
print 'FACCIA'
select count(*) from unisys.dbo.news where contains (text, 'FACCIA')
print 'MAGGIORE'
select count(*) from unisys.dbo.news where contains (text, 'MAGGIORE')
print 'NECESSARIO'
select count(*) from unisys.dbo.news where contains (text, 'NECESSARIO')
print 'TROVARE'
select count(*) from unisys.dbo.news where contains (text, 'TROVARE')
print 'ADESSO'
select count(*) from unisys.dbo.news where contains (text, 'ADESSO')
print 'VIAGGIO'
select count(*) from unisys.dbo.news where contains (text, 'VIAGGIO')
print 'MESSA'
select count(*) from unisys.dbo.news where contains (text, 'MESSA')
print 'SCUOLA'
select count(*) from unisys.dbo.news where contains (text, 'SCUOLA')
print 'TERRA'
select count(*) from unisys.dbo.news where contains (text, 'TERRA')
print 'CINQUE'
select count(*) from unisys.dbo.news where contains (text, 'CINQUE')
print 'ULTIME'
select count(*) from unisys.dbo.news where contains (text, 'ULTIME')
print 'FINALMENTE'
select count(*) from unisys.dbo.news where contains (text, 'FINALMENTE')
print 'GRUPPI'
select count(*) from unisys.dbo.news where contains (text, 'GRUPPI')
print 'PROBLEMI'
select count(*) from unisys.dbo.news where contains (text, 'PROBLEMI')
print 'SERVIZIO'
select count(*) from unisys.dbo.news where contains (text, 'SERVIZIO')
print 'GRANDI'
select count(*) from unisys.dbo.news where contains (text, 'GRANDI')
print 'COPPA'
select count(*) from unisys.dbo.news where contains (text, 'COPPA')
print 'POSTI'
select count(*) from unisys.dbo.news where contains (text, 'POSTI')
print 'POTER'
select count(*) from unisys.dbo.news where contains (text, 'POTER')
print 'POMERIGGIO'
select count(*) from unisys.dbo.news where contains (text, 'POMERIGGIO')
print 'IPOTESI'
select count(*) from unisys.dbo.news where contains (text, 'IPOTESI')
print 'CURA'
select count(*) from unisys.dbo.news where contains (text, 'CURA')
print 'VUOL'
select count(*) from unisys.dbo.news where contains (text, 'VUOL')
print 'CORPO'
select count(*) from unisys.dbo.news where contains (text, 'CORPO')
print 'QUOTA'
select count(*) from unisys.dbo.news where contains (text, 'QUOTA')
print 'FORMA'
select count(*) from unisys.dbo.news where contains (text, 'FORMA')
print 'TALE'
select count(*) from unisys.dbo.news where contains (text, 'TALE')
print 'SALA'
select count(*) from unisys.dbo.news where contains (text, 'SALA')
print 'TUTTA'
select count(*) from unisys.dbo.news where contains (text, 'TUTTA')
print 'MODO'
select count(*) from unisys.dbo.news where contains (text, 'MODO')
print 'CARABINIERI'
select count(*) from unisys.dbo.news where contains (text, 'CARABINIERI')
print 'COMUNQUE'
select count(*) from unisys.dbo.news where contains (text, 'COMUNQUE')
print 'LIBERO'
select count(*) from unisys.dbo.news where contains (text, 'LIBERO')
print 'VISTO'
select count(*) from unisys.dbo.news where contains (text, 'VISTO')
print 'DONNE'
select count(*) from unisys.dbo.news where contains (text, 'DONNE')
print 'CAMPO'
select count(*) from unisys.dbo.news where contains (text, 'CAMPO')
print 'ZONA'
select count(*) from unisys.dbo.news where contains (text, 'ZONA')
print 'DURANTE'
select count(*) from unisys.dbo.news where contains (text, 'DURANTE')
print 'MARIA'
select count(*) from unisys.dbo.news where contains (text, 'MARIA')
print 'CRISI'
select count(*) from unisys.dbo.news where contains (text, 'CRISI')
print 'MUSICA'
select count(*) from unisys.dbo.news where contains (text, 'MUSICA')
print 'VINTO'
select count(*) from unisys.dbo.news where contains (text, 'VINTO')
print 'ATTENZIONE'
select count(*) from unisys.dbo.news where contains (text, 'ATTENZIONE')
print 'SETTIMANA'
select count(*) from unisys.dbo.news where contains (text, 'SETTIMANA')
print 'PIERO'
select count(*) from unisys.dbo.news where contains (text, 'PIERO')
print 'FUTURO'
select count(*) from unisys.dbo.news where contains (text, 'FUTURO')
print 'TRATTA'
select count(*) from unisys.dbo.news where contains (text, 'TRATTA')
print 'PRESSO'
select count(*) from unisys.dbo.news where contains (text, 'PRESSO')
print 'MAGGIO'
select count(*) from unisys.dbo.news where contains (text, 'MAGGIO')
print 'DICEMBRE'
select count(*) from unisys.dbo.news where contains (text, 'DICEMBRE')
print 'DATA'
select count(*) from unisys.dbo.news where contains (text, 'DATA')
print 'CHIESTO'
select count(*) from unisys.dbo.news where contains (text, 'CHIESTO')
print 'DIETRO'
select count(*) from unisys.dbo.news where contains (text, 'DIETRO')
print 'NUOVA'
select count(*) from unisys.dbo.news where contains (text, 'NUOVA')
print 'CITTADINI'
select count(*) from unisys.dbo.news where contains (text, 'CITTADINI')
print 'ANSA'
select count(*) from unisys.dbo.news where contains (text, 'ANSA')
print 'REALT�'
select count(*) from unisys.dbo.news where contains (text, 'REALT�')
print 'LIVELLO'
select count(*) from unisys.dbo.news where contains (text, 'LIVELLO')
print 'QUALIT�'
select count(*) from unisys.dbo.news where contains (text, 'QUALIT�')
print 'UNITI'
select count(*) from unisys.dbo.news where contains (text, 'UNITI')
print 'METRI'
select count(*) from unisys.dbo.news where contains (text, 'METRI')
print 'PASSO'
select count(*) from unisys.dbo.news where contains (text, 'PASSO')
print 'VOCE'
select count(*) from unisys.dbo.news where contains (text, 'VOCE')
print 'GIOVANNI'
select count(*) from unisys.dbo.news where contains (text, 'GIOVANNI')
print 'CAPO'
select count(*) from unisys.dbo.news where contains (text, 'CAPO')
print 'DATO'
select count(*) from unisys.dbo.news where contains (text, 'DATO')
print 'LONDRA'
select count(*) from unisys.dbo.news where contains (text, 'LONDRA')
print 'GUIDA'
select count(*) from unisys.dbo.news where contains (text, 'GUIDA')
print 'VENGONO'
select count(*) from unisys.dbo.news where contains (text, 'VENGONO')
print 'FIGLI'
select count(*) from unisys.dbo.news where contains (text, 'FIGLI')
print 'OCCHI'
select count(*) from unisys.dbo.news where contains (text, 'OCCHI')
print 'PROBABILMENTE'
select count(*) from unisys.dbo.news where contains (text, 'PROBABILMENTE')
print 'POLITICA'
select count(*) from unisys.dbo.news where contains (text, 'POLITICA')
print 'QUEL'
select count(*) from unisys.dbo.news where contains (text, 'QUEL')
print 'MINUTI'
select count(*) from unisys.dbo.news where contains (text, 'MINUTI')
print 'ARRIVA'
select count(*) from unisys.dbo.news where contains (text, 'ARRIVA')
print 'NELLO'
select count(*) from unisys.dbo.news where contains (text, 'NELLO')
print 'TITOLI'
select count(*) from unisys.dbo.news where contains (text, 'TITOLI')
print 'SPECIE'
select count(*) from unisys.dbo.news where contains (text, 'SPECIE')
print 'DENTRO'
select count(*) from unisys.dbo.news where contains (text, 'DENTRO')
print 'NERO'
select count(*) from unisys.dbo.news where contains (text, 'NERO')
print 'BELLA'
select count(*) from unisys.dbo.news where contains (text, 'BELLA')
print 'VANNO'
select count(*) from unisys.dbo.news where contains (text, 'VANNO')
print 'CITT�'
select count(*) from unisys.dbo.news where contains (text, 'CITT�')
print 'ARRIVO'
select count(*) from unisys.dbo.news where contains (text, 'ARRIVO')
print 'FATTI'
select count(*) from unisys.dbo.news where contains (text, 'FATTI')
print 'DEVE'
select count(*) from unisys.dbo.news where contains (text, 'DEVE')
print 'DATI'
select count(*) from unisys.dbo.news where contains (text, 'DATI')
print 'LAVORARE'
select count(*) from unisys.dbo.news where contains (text, 'LAVORARE')
print 'VOLUTO'
select count(*) from unisys.dbo.news where contains (text, 'VOLUTO')
print 'AUTORIT�'
select count(*) from unisys.dbo.news where contains (text, 'AUTORIT�')
print 'METTERE'
select count(*) from unisys.dbo.news where contains (text, 'METTERE')
print 'SOPRATTUTTO'
select count(*) from unisys.dbo.news where contains (text, 'SOPRATTUTTO')
print 'MAGGIORANZA'
select count(*) from unisys.dbo.news where contains (text, 'MAGGIORANZA')
print 'NOTTE'
select count(*) from unisys.dbo.news where contains (text, 'NOTTE')
print 'POLITICHE'
select count(*) from unisys.dbo.news where contains (text, 'POLITICHE')
print 'CONTRARIO'
select count(*) from unisys.dbo.news where contains (text, 'CONTRARIO')
print 'MORTO'
select count(*) from unisys.dbo.news where contains (text, 'MORTO')
print 'DICHIARATO'
select count(*) from unisys.dbo.news where contains (text, 'DICHIARATO')
print 'PERIODO'
select count(*) from unisys.dbo.news where contains (text, 'PERIODO')
print 'PIANO'
select count(*) from unisys.dbo.news where contains (text, 'PIANO')
print 'MOMENTO'
select count(*) from unisys.dbo.news where contains (text, 'MOMENTO')
print 'INTANTO'
select count(*) from unisys.dbo.news where contains (text, 'INTANTO')
print 'BASTA'
select count(*) from unisys.dbo.news where contains (text, 'BASTA')
print 'VECCHIO'
select count(*) from unisys.dbo.news where contains (text, 'VECCHIO')
print 'PROGETTO'
select count(*) from unisys.dbo.news where contains (text, 'PROGETTO')
print 'DIFFICILE'
select count(*) from unisys.dbo.news where contains (text, 'DIFFICILE')
print 'QUESTE'
select count(*) from unisys.dbo.news where contains (text, 'QUESTE')
print 'MILLE'
select count(*) from unisys.dbo.news where contains (text, 'MILLE')
print 'ANTONIO'
select count(*) from unisys.dbo.news where contains (text, 'ANTONIO')
print 'DUNQUE'
select count(*) from unisys.dbo.news where contains (text, 'DUNQUE')
print 'FONDO'
select count(*) from unisys.dbo.news where contains (text, 'FONDO')
print 'NUOVI'
select count(*) from unisys.dbo.news where contains (text, 'NUOVI')
print 'PRODOTTO'
select count(*) from unisys.dbo.news where contains (text, 'PRODOTTO')
print 'BIANCO'
select count(*) from unisys.dbo.news where contains (text, 'BIANCO')
print 'NOTIZIA'
select count(*) from unisys.dbo.news where contains (text, 'NOTIZIA')
print 'STUDIO'
select count(*) from unisys.dbo.news where contains (text, 'STUDIO')
print 'DARE'
select count(*) from unisys.dbo.news where contains (text, 'DARE')
print 'ORDINE'
select count(*) from unisys.dbo.news where contains (text, 'ORDINE')
print 'OPERE'
select count(*) from unisys.dbo.news where contains (text, 'OPERE')
print 'DAGLI'
select count(*) from unisys.dbo.news where contains (text, 'DAGLI')
print 'NEPPURE'
select count(*) from unisys.dbo.news where contains (text, 'NEPPURE')
print 'SICURO'
select count(*) from unisys.dbo.news where contains (text, 'SICURO')
print 'SIGNIFICA'
select count(*) from unisys.dbo.news where contains (text, 'SIGNIFICA')
print 'RAGAZZI'
select count(*) from unisys.dbo.news where contains (text, 'RAGAZZI')
print 'AVVOCATO'
select count(*) from unisys.dbo.news where contains (text, 'AVVOCATO')
print 'GIUNTA'
select count(*) from unisys.dbo.news where contains (text, 'GIUNTA')
print 'SERGIO'
select count(*) from unisys.dbo.news where contains (text, 'SERGIO')
print 'DOVUTO'
select count(*) from unisys.dbo.news where contains (text, 'DOVUTO')
print 'PROVA'
select count(*) from unisys.dbo.news where contains (text, 'PROVA')
print 'POTUTO'
select count(*) from unisys.dbo.news where contains (text, 'POTUTO')
print 'CHIAMA'
select count(*) from unisys.dbo.news where contains (text, 'CHIAMA')
print 'LIRE'
select count(*) from unisys.dbo.news where contains (text, 'LIRE')
print 'FARSI'
select count(*) from unisys.dbo.news where contains (text, 'FARSI')
print 'GENERALE'
select count(*) from unisys.dbo.news where contains (text, 'GENERALE')
print 'MOLTE'
select count(*) from unisys.dbo.news where contains (text, 'MOLTE')
print 'SCRIVE'
select count(*) from unisys.dbo.news where contains (text, 'SCRIVE')
print 'CONFERMA'
select count(*) from unisys.dbo.news where contains (text, 'CONFERMA')
print 'SULL'
select count(*) from unisys.dbo.news where contains (text, 'SULL')
print 'OTTOBRE'
select count(*) from unisys.dbo.news where contains (text, 'OTTOBRE')
print 'GIORNALISTI'
select count(*) from unisys.dbo.news where contains (text, 'GIORNALISTI')
print 'MATTINA'
select count(*) from unisys.dbo.news where contains (text, 'MATTINA')
print 'MONDIALE'
select count(*) from unisys.dbo.news where contains (text, 'MONDIALE')
print 'VENERD�'
select count(*) from unisys.dbo.news where contains (text, 'VENERD�')
print 'PREZZO'
select count(*) from unisys.dbo.news where contains (text, 'PREZZO')
print 'DALLO'
select count(*) from unisys.dbo.news where contains (text, 'DALLO')
print 'ALCUNI'
select count(*) from unisys.dbo.news where contains (text, 'ALCUNI')
print 'RITORNO'
select count(*) from unisys.dbo.news where contains (text, 'RITORNO')
print 'PORTARE'
select count(*) from unisys.dbo.news where contains (text, 'PORTARE')
print 'AVREBBE'
select count(*) from unisys.dbo.news where contains (text, 'AVREBBE')
print 'DECISO'
select count(*) from unisys.dbo.news where contains (text, 'DECISO')
print 'INFINE'
select count(*) from unisys.dbo.news where contains (text, 'INFINE')
print 'AMICO'
select count(*) from unisys.dbo.news where contains (text, 'AMICO')
print 'APRILE'
select count(*) from unisys.dbo.news where contains (text, 'APRILE')
print 'MEDIA'
select count(*) from unisys.dbo.news where contains (text, 'MEDIA')
print 'INGLESE'
select count(*) from unisys.dbo.news where contains (text, 'INGLESE')
print 'PERDERE'
select count(*) from unisys.dbo.news where contains (text, 'PERDERE')
print 'REGIONE'
select count(*) from unisys.dbo.news where contains (text, 'REGIONE')
print 'TUTTE'
select count(*) from unisys.dbo.news where contains (text, 'TUTTE')
print 'DIRETTORE'
select count(*) from unisys.dbo.news where contains (text, 'DIRETTORE')
print 'ITALIANO'
select count(*) from unisys.dbo.news where contains (text, 'ITALIANO')
print 'STAVA'
select count(*) from unisys.dbo.news where contains (text, 'STAVA')
print 'STORICO'
select count(*) from unisys.dbo.news where contains (text, 'STORICO')
print 'TERZO'
select count(*) from unisys.dbo.news where contains (text, 'TERZO')
print 'GENNAIO'
select count(*) from unisys.dbo.news where contains (text, 'GENNAIO')
print 'PARLA'
select count(*) from unisys.dbo.news where contains (text, 'PARLA')
print 'RUOLO'
select count(*) from unisys.dbo.news where contains (text, 'RUOLO')
print 'GUERRA'
select count(*) from unisys.dbo.news where contains (text, 'GUERRA')
print 'SOLUZIONE'
select count(*) from unisys.dbo.news where contains (text, 'SOLUZIONE')
print 'ALMENO'
select count(*) from unisys.dbo.news where contains (text, 'ALMENO')
print 'AVR�'
select count(*) from unisys.dbo.news where contains (text, 'AVR�')
print 'DOVR�'
select count(*) from unisys.dbo.news where contains (text, 'DOVR�')
print 'POTREBBE'
select count(*) from unisys.dbo.news where contains (text, 'POTREBBE')
print 'APPUNTO'
select count(*) from unisys.dbo.news where contains (text, 'APPUNTO')
print 'NESSUNA'
select count(*) from unisys.dbo.news where contains (text, 'NESSUNA')
print 'SQUADRA'
select count(*) from unisys.dbo.news where contains (text, 'SQUADRA')
print 'QUALCOSA'
select count(*) from unisys.dbo.news where contains (text, 'QUALCOSA')
print 'SOLE'
select count(*) from unisys.dbo.news where contains (text, 'SOLE')
print 'PIETRO'
select count(*) from unisys.dbo.news where contains (text, 'PIETRO')
print 'INTORNO'
select count(*) from unisys.dbo.news where contains (text, 'INTORNO')
print 'DECISIONE'
select count(*) from unisys.dbo.news where contains (text, 'DECISIONE')
print 'PADRE'
select count(*) from unisys.dbo.news where contains (text, 'PADRE')
print 'DIRITTO'
select count(*) from unisys.dbo.news where contains (text, 'DIRITTO')
print 'FASE'
select count(*) from unisys.dbo.news where contains (text, 'FASE')
print 'RICHIESTA'
select count(*) from unisys.dbo.news where contains (text, 'RICHIESTA')
print 'CAUSA'
select count(*) from unisys.dbo.news where contains (text, 'CAUSA')
print 'NOSTRO'
select count(*) from unisys.dbo.news where contains (text, 'NOSTRO')
print 'ANZI'
select count(*) from unisys.dbo.news where contains (text, 'ANZI')
print 'ANDARE'
select count(*) from unisys.dbo.news where contains (text, 'ANDARE')
print 'FACENDO'
select count(*) from unisys.dbo.news where contains (text, 'FACENDO')
print 'PUNTA'
select count(*) from unisys.dbo.news where contains (text, 'PUNTA')
print 'DOBBIAMO'
select count(*) from unisys.dbo.news where contains (text, 'DOBBIAMO')
print 'ATTUALE'
select count(*) from unisys.dbo.news where contains (text, 'ATTUALE')
print 'SCRITTO'
select count(*) from unisys.dbo.news where contains (text, 'SCRITTO')
print 'MINISTRO'
select count(*) from unisys.dbo.news where contains (text, 'MINISTRO')
print 'PRENDERE'
select count(*) from unisys.dbo.news where contains (text, 'PRENDERE')
print 'APERTO'
select count(*) from unisys.dbo.news where contains (text, 'APERTO')
print 'FORZA'
select count(*) from unisys.dbo.news where contains (text, 'FORZA')
print 'GIOVANI'
select count(*) from unisys.dbo.news where contains (text, 'GIOVANI')
print 'PARLAMENTO'
select count(*) from unisys.dbo.news where contains (text, 'PARLAMENTO')
print 'DIVERSI'
select count(*) from unisys.dbo.news where contains (text, 'DIVERSI')
print 'CAMERA'
select count(*) from unisys.dbo.news where contains (text, 'CAMERA')
print 'ANDATO'
select count(*) from unisys.dbo.news where contains (text, 'ANDATO')
print 'GIORNALI'
select count(*) from unisys.dbo.news where contains (text, 'GIORNALI')
print 'COLLABORAZIONE'
select count(*) from unisys.dbo.news where contains (text, 'COLLABORAZIONE')
print 'QUELLE'
select count(*) from unisys.dbo.news where contains (text, 'QUELLE')
print 'FAVORE'
select count(*) from unisys.dbo.news where contains (text, 'FAVORE')
print 'RETE'
select count(*) from unisys.dbo.news where contains (text, 'RETE')
print 'TORNARE'
select count(*) from unisys.dbo.news where contains (text, 'TORNARE')
print 'BILANCIO'
select count(*) from unisys.dbo.news where contains (text, 'BILANCIO')
print 'SAPERE'
select count(*) from unisys.dbo.news where contains (text, 'SAPERE')
print 'SEGNO'
select count(*) from unisys.dbo.news where contains (text, 'SEGNO')
print 'GENITORI'
select count(*) from unisys.dbo.news where contains (text, 'GENITORI')
print 'CONFRONTI'
select count(*) from unisys.dbo.news where contains (text, 'CONFRONTI')
print 'NEGLI'
select count(*) from unisys.dbo.news where contains (text, 'NEGLI')
print 'CULTURA'
select count(*) from unisys.dbo.news where contains (text, 'CULTURA')
print 'APERTA'
select count(*) from unisys.dbo.news where contains (text, 'APERTA')
print 'MALE'
select count(*) from unisys.dbo.news where contains (text, 'MALE')
print 'VISTA'
select count(*) from unisys.dbo.news where contains (text, 'VISTA')
print 'INIZIO'
select count(*) from unisys.dbo.news where contains (text, 'INIZIO')
print 'SITUAZIONE'
select count(*) from unisys.dbo.news where contains (text, 'SITUAZIONE')
print 'NIENTE'
select count(*) from unisys.dbo.news where contains (text, 'NIENTE')
print 'PERSINO'
select count(*) from unisys.dbo.news where contains (text, 'PERSINO')
print 'VALORE'
select count(*) from unisys.dbo.news where contains (text, 'VALORE')
print 'SICUREZZA'
select count(*) from unisys.dbo.news where contains (text, 'SICUREZZA')
print 'PARTITO'
select count(*) from unisys.dbo.news where contains (text, 'PARTITO')
print 'TEMA'
select count(*) from unisys.dbo.news where contains (text, 'TEMA')
print 'PUNTO'
select count(*) from unisys.dbo.news where contains (text, 'PUNTO')
print 'IMMAGINE'
select count(*) from unisys.dbo.news where contains (text, 'IMMAGINE')
print 'SOCIET�'
select count(*) from unisys.dbo.news where contains (text, 'SOCIET�')
print 'MEGLIO'
select count(*) from unisys.dbo.news where contains (text, 'MEGLIO')
print 'VARI'
select count(*) from unisys.dbo.news where contains (text, 'VARI')
print 'VUOLE'
select count(*) from unisys.dbo.news where contains (text, 'VUOLE')
print 'PRESENTATO'
select count(*) from unisys.dbo.news where contains (text, 'PRESENTATO')
print 'QUATTRO'
select count(*) from unisys.dbo.news where contains (text, 'QUATTRO')
print 'IMPORTANTE'
select count(*) from unisys.dbo.news where contains (text, 'IMPORTANTE')
print 'FIGLIO'
select count(*) from unisys.dbo.news where contains (text, 'FIGLIO')
print 'MONDO'
select count(*) from unisys.dbo.news where contains (text, 'MONDO')
print 'APPENA'
select count(*) from unisys.dbo.news where contains (text, 'APPENA')
print 'PROSSIMA'
select count(*) from unisys.dbo.news where contains (text, 'PROSSIMA')
print 'ENTRO'
select count(*) from unisys.dbo.news where contains (text, 'ENTRO')
print 'GIANNI'
select count(*) from unisys.dbo.news where contains (text, 'GIANNI')
print 'SOLDI'
select count(*) from unisys.dbo.news where contains (text, 'SOLDI')
print 'GRAZIE'
select count(*) from unisys.dbo.news where contains (text, 'GRAZIE')
print 'MAGARI'
select count(*) from unisys.dbo.news where contains (text, 'MAGARI')
print 'DISPOSIZIONE'
select count(*) from unisys.dbo.news where contains (text, 'DISPOSIZIONE')
print 'LETTO'
select count(*) from unisys.dbo.news where contains (text, 'LETTO')
print 'BREVE'
select count(*) from unisys.dbo.news where contains (text, 'BREVE')
print 'ENTRARE'
select count(*) from unisys.dbo.news where contains (text, 'ENTRARE')
print 'MIGLIORE'
select count(*) from unisys.dbo.news where contains (text, 'MIGLIORE')
print 'ANNUNCIATO'
select count(*) from unisys.dbo.news where contains (text, 'ANNUNCIATO')
print 'SUGLI'
select count(*) from unisys.dbo.news where contains (text, 'SUGLI')
print 'SCORSO'
select count(*) from unisys.dbo.news where contains (text, 'SCORSO')
print 'TROPPO'
select count(*) from unisys.dbo.news where contains (text, 'TROPPO')
print 'NOTA'
select count(*) from unisys.dbo.news where contains (text, 'NOTA')
print 'AUMENTO'
select count(*) from unisys.dbo.news where contains (text, 'AUMENTO')
print 'PURE'
select count(*) from unisys.dbo.news where contains (text, 'PURE')
print 'VERIT�'
select count(*) from unisys.dbo.news where contains (text, 'VERIT�')
print 'APPUNTAMENTO'
select count(*) from unisys.dbo.news where contains (text, 'APPUNTAMENTO')
print 'NOME'
select count(*) from unisys.dbo.news where contains (text, 'NOME')
print 'PARTITA'
select count(*) from unisys.dbo.news where contains (text, 'PARTITA')
print 'QUINDI'
select count(*) from unisys.dbo.news where contains (text, 'QUINDI')
print 'PUBBLICA'
select count(*) from unisys.dbo.news where contains (text, 'PUBBLICA')
print 'TECNICO'
select count(*) from unisys.dbo.news where contains (text, 'TECNICO')
print 'ROMANO'
select count(*) from unisys.dbo.news where contains (text, 'ROMANO')
print 'NONOSTANTE'
select count(*) from unisys.dbo.news where contains (text, 'NONOSTANTE')
print 'CONTO'
select count(*) from unisys.dbo.news where contains (text, 'CONTO')
print 'PENSARE'
select count(*) from unisys.dbo.news where contains (text, 'PENSARE')
print 'POTERE'
select count(*) from unisys.dbo.news where contains (text, 'POTERE')
print 'PAESE'
select count(*) from unisys.dbo.news where contains (text, 'PAESE')
print 'STAGIONE'
select count(*) from unisys.dbo.news where contains (text, 'STAGIONE')
print 'FORTUNA'
select count(*) from unisys.dbo.news where contains (text, 'FORTUNA')
print 'RICORDA'
select count(*) from unisys.dbo.news where contains (text, 'RICORDA')
print 'SETTORE'
select count(*) from unisys.dbo.news where contains (text, 'SETTORE')
print 'QUALCUNO'
select count(*) from unisys.dbo.news where contains (text, 'QUALCUNO')
print 'FORSE'
select count(*) from unisys.dbo.news where contains (text, 'FORSE')
print 'QUELL'
select count(*) from unisys.dbo.news where contains (text, 'QUELL')
print 'AGOSTO'
select count(*) from unisys.dbo.news where contains (text, 'AGOSTO')
print 'AUTORE'
select count(*) from unisys.dbo.news where contains (text, 'AUTORE')
print 'BATTAGLIA'
select count(*) from unisys.dbo.news where contains (text, 'BATTAGLIA')
print 'ATTO'
select count(*) from unisys.dbo.news where contains (text, 'ATTO')
print 'VICINO'
select count(*) from unisys.dbo.news where contains (text, 'VICINO')
print 'PERSONE'
select count(*) from unisys.dbo.news where contains (text, 'PERSONE')
print 'CONSIGLIO'
select count(*) from unisys.dbo.news where contains (text, 'CONSIGLIO')
print 'SARANNO'
select count(*) from unisys.dbo.news where contains (text, 'SARANNO')
print 'ABBIA'
select count(*) from unisys.dbo.news where contains (text, 'ABBIA')
print 'AMERICA'
select count(*) from unisys.dbo.news where contains (text, 'AMERICA')
print 'PROTAGONISTA'
select count(*) from unisys.dbo.news where contains (text, 'PROTAGONISTA')
print 'POPOLARE'
select count(*) from unisys.dbo.news where contains (text, 'POPOLARE')
print 'RISPONDE'
select count(*) from unisys.dbo.news where contains (text, 'RISPONDE')
print 'SPIEGA'
select count(*) from unisys.dbo.news where contains (text, 'SPIEGA')
print 'SPESSO'
select count(*) from unisys.dbo.news where contains (text, 'SPESSO')
print 'ECCO'
select count(*) from unisys.dbo.news where contains (text, 'ECCO')
print 'REPUBBLICA'
select count(*) from unisys.dbo.news where contains (text, 'REPUBBLICA')
print 'PIAZZA'
select count(*) from unisys.dbo.news where contains (text, 'PIAZZA')
print 'ATTESA'
select count(*) from unisys.dbo.news where contains (text, 'ATTESA')
print 'SISTEMA'
select count(*) from unisys.dbo.news where contains (text, 'SISTEMA')
print 'ARTE'
select count(*) from unisys.dbo.news where contains (text, 'ARTE')
print 'VERA'
select count(*) from unisys.dbo.news where contains (text, 'VERA')
print 'CARTA'
select count(*) from unisys.dbo.news where contains (text, 'CARTA')
print 'RIMASTO'
select count(*) from unisys.dbo.news where contains (text, 'RIMASTO')
print 'GENERE'
select count(*) from unisys.dbo.news where contains (text, 'GENERE')
print 'LIBRO'
select count(*) from unisys.dbo.news where contains (text, 'LIBRO')
print 'AMICI'
select count(*) from unisys.dbo.news where contains (text, 'AMICI')
print 'GESTIONE'
select count(*) from unisys.dbo.news where contains (text, 'GESTIONE')
print 'RESTO'
select count(*) from unisys.dbo.news where contains (text, 'RESTO')
print 'DIREZIONE'
select count(*) from unisys.dbo.news where contains (text, 'DIREZIONE')
print 'OTTO'
select count(*) from unisys.dbo.news where contains (text, 'OTTO')
print 'VERDE'
select count(*) from unisys.dbo.news where contains (text, 'VERDE')
print 'PAROLE'
select count(*) from unisys.dbo.news where contains (text, 'PAROLE')
print 'CONTROLLO'
select count(*) from unisys.dbo.news where contains (text, 'CONTROLLO')
print 'RISULTATO'
select count(*) from unisys.dbo.news where contains (text, 'RISULTATO')
print 'UFFICIO'
select count(*) from unisys.dbo.news where contains (text, 'UFFICIO')
print 'POSSA'
select count(*) from unisys.dbo.news where contains (text, 'POSSA')
print 'PREMIO'
select count(*) from unisys.dbo.news where contains (text, 'PREMIO')
print 'INTERNO'
select count(*) from unisys.dbo.news where contains (text, 'INTERNO')
print 'QUALI'
select count(*) from unisys.dbo.news where contains (text, 'QUALI')
print 'QUEI'
select count(*) from unisys.dbo.news where contains (text, 'QUEI')
print 'PICCOLI'
select count(*) from unisys.dbo.news where contains (text, 'PICCOLI')
print 'LUGLIO'
select count(*) from unisys.dbo.news where contains (text, 'LUGLIO')
print 'FRONTE'
select count(*) from unisys.dbo.news where contains (text, 'FRONTE')
print 'AVEVANO'
select count(*) from unisys.dbo.news where contains (text, 'AVEVANO')
print 'MEZZO'
select count(*) from unisys.dbo.news where contains (text, 'MEZZO')
print 'TANTO'
select count(*) from unisys.dbo.news where contains (text, 'TANTO')
print 'GIORNATA'
select count(*) from unisys.dbo.news where contains (text, 'GIORNATA')
print 'NECESSIT�'
select count(*) from unisys.dbo.news where contains (text, 'NECESSIT�')
print 'INCHIESTA'
select count(*) from unisys.dbo.news where contains (text, 'INCHIESTA')
print 'PERSONA'
select count(*) from unisys.dbo.news where contains (text, 'PERSONA')
print 'STORIA'
select count(*) from unisys.dbo.news where contains (text, 'STORIA')
print 'PRESENTA'
select count(*) from unisys.dbo.news where contains (text, 'PRESENTA')
print 'LAVORI'
select count(*) from unisys.dbo.news where contains (text, 'LAVORI')
print 'NATO'
select count(*) from unisys.dbo.news where contains (text, 'NATO')
print 'GIUGNO'
select count(*) from unisys.dbo.news where contains (text, 'GIUGNO')
print 'MILANO'
select count(*) from unisys.dbo.news where contains (text, 'MILANO')
print 'CENTRALE'
select count(*) from unisys.dbo.news where contains (text, 'CENTRALE')
print 'INSIEME'
select count(*) from unisys.dbo.news where contains (text, 'INSIEME')
print 'RAGIONE'
select count(*) from unisys.dbo.news where contains (text, 'RAGIONE')
print 'SETTEMBRE'
select count(*) from unisys.dbo.news where contains (text, 'SETTEMBRE')
print 'PUBBLICO'
select count(*) from unisys.dbo.news where contains (text, 'PUBBLICO')
print 'RESTA'
select count(*) from unisys.dbo.news where contains (text, 'RESTA')
print 'PARLARE'
select count(*) from unisys.dbo.news where contains (text, 'PARLARE')
print 'DESTRA'
select count(*) from unisys.dbo.news where contains (text, 'DESTRA')
print 'MILIARDI'
select count(*) from unisys.dbo.news where contains (text, 'MILIARDI')
print 'PARLATO'
select count(*) from unisys.dbo.news where contains (text, 'PARLATO')
print 'LUNGA'
select count(*) from unisys.dbo.news where contains (text, 'LUNGA')
print 'PAGINE'
select count(*) from unisys.dbo.news where contains (text, 'PAGINE')
print 'ESPERIENZA'
select count(*) from unisys.dbo.news where contains (text, 'ESPERIENZA')
print 'ABBIAMO'
select count(*) from unisys.dbo.news where contains (text, 'ABBIAMO')
print 'MOVIMENTO'
select count(*) from unisys.dbo.news where contains (text, 'MOVIMENTO')
print 'FAMIGLIA'
select count(*) from unisys.dbo.news where contains (text, 'FAMIGLIA')
print 'MORTE'
select count(*) from unisys.dbo.news where contains (text, 'MORTE')
print 'COMUNE'
select count(*) from unisys.dbo.news where contains (text, 'COMUNE')
print 'CARCERE'
select count(*) from unisys.dbo.news where contains (text, 'CARCERE')
print 'MAGGIOR'
select count(*) from unisys.dbo.news where contains (text, 'MAGGIOR')
print 'ARRIVATO'
select count(*) from unisys.dbo.news where contains (text, 'ARRIVATO')
print 'CAMPAGNA'
select count(*) from unisys.dbo.news where contains (text, 'CAMPAGNA')
print 'SOLITO'
select count(*) from unisys.dbo.news where contains (text, 'SOLITO')
print 'SECONDA'
select count(*) from unisys.dbo.news where contains (text, 'SECONDA')
print 'POSSO'
select count(*) from unisys.dbo.news where contains (text, 'POSSO')
print 'DIVENTARE'
select count(*) from unisys.dbo.news where contains (text, 'DIVENTARE')
print 'MARZO'
select count(*) from unisys.dbo.news where contains (text, 'MARZO')
print 'PIUTTOSTO'
select count(*) from unisys.dbo.news where contains (text, 'PIUTTOSTO')
print 'BASE'
select count(*) from unisys.dbo.news where contains (text, 'BASE')
print 'FOTO'
select count(*) from unisys.dbo.news where contains (text, 'FOTO')
print 'CARLO'
select count(*) from unisys.dbo.news where contains (text, 'CARLO')
print 'FUORI'
select count(*) from unisys.dbo.news where contains (text, 'FUORI')
print 'DAVANTI'
select count(*) from unisys.dbo.news where contains (text, 'DAVANTI')
print 'PROPRIA'
select count(*) from unisys.dbo.news where contains (text, 'PROPRIA')
print 'NESSUN'
select count(*) from unisys.dbo.news where contains (text, 'NESSUN')
print 'LINEA'
select count(*) from unisys.dbo.news where contains (text, 'LINEA')
print 'CONTINUA'
select count(*) from unisys.dbo.news where contains (text, 'CONTINUA')
print 'IDEA'
select count(*) from unisys.dbo.news where contains (text, 'IDEA')
print 'VERO'
select count(*) from unisys.dbo.news where contains (text, 'VERO')
print 'COMPAGNIA'
select count(*) from unisys.dbo.news where contains (text, 'COMPAGNIA')
print 'AVANTI'
select count(*) from unisys.dbo.news where contains (text, 'AVANTI')
print 'SCELTA'
select count(*) from unisys.dbo.news where contains (text, 'SCELTA')
print 'POTEVA'
select count(*) from unisys.dbo.news where contains (text, 'POTEVA')
print 'SCORSA'
select count(*) from unisys.dbo.news where contains (text, 'SCORSA')
print 'TIPO'
select count(*) from unisys.dbo.news where contains (text, 'TIPO')
print 'SOLTANTO'
select count(*) from unisys.dbo.news where contains (text, 'SOLTANTO')
print 'SIAMO'
select count(*) from unisys.dbo.news where contains (text, 'SIAMO')
print 'SULLE'
select count(*) from unisys.dbo.news where contains (text, 'SULLE')
print 'SENSO'
select count(*) from unisys.dbo.news where contains (text, 'SENSO')
print 'ALTA'
select count(*) from unisys.dbo.news where contains (text, 'ALTA')
print 'CONDIZIONI'
select count(*) from unisys.dbo.news where contains (text, 'CONDIZIONI')
print 'MESE'
select count(*) from unisys.dbo.news where contains (text, 'MESE')
print 'POCHE'
select count(*) from unisys.dbo.news where contains (text, 'POCHE')
print 'DIRE'
select count(*) from unisys.dbo.news where contains (text, 'DIRE')
print 'GARA'
select count(*) from unisys.dbo.news where contains (text, 'GARA')
print 'SEGUITO'
select count(*) from unisys.dbo.news where contains (text, 'SEGUITO')
print 'PAURA'
select count(*) from unisys.dbo.news where contains (text, 'PAURA')
print 'DOVREBBE'
select count(*) from unisys.dbo.news where contains (text, 'DOVREBBE')
print 'MESSO'
select count(*) from unisys.dbo.news where contains (text, 'MESSO')
print 'SINISTRA'
select count(*) from unisys.dbo.news where contains (text, 'SINISTRA')
print 'BANCA'
select count(*) from unisys.dbo.news where contains (text, 'BANCA')
print 'PUBBLICI'
select count(*) from unisys.dbo.news where contains (text, 'PUBBLICI')
print 'NESSUNO'
select count(*) from unisys.dbo.news where contains (text, 'NESSUNO')
print 'PREVISTO'
select count(*) from unisys.dbo.news where contains (text, 'PREVISTO')
print 'GERMANIA'
select count(*) from unisys.dbo.news where contains (text, 'GERMANIA')
print 'VOLTE'
select count(*) from unisys.dbo.news where contains (text, 'VOLTE')
print 'AMMINISTRAZIONE'
select count(*) from unisys.dbo.news where contains (text, 'AMMINISTRAZIONE')
print 'MADRE'
select count(*) from unisys.dbo.news where contains (text, 'MADRE')
print 'GRAN'
select count(*) from unisys.dbo.news where contains (text, 'GRAN')
print 'METTE'
select count(*) from unisys.dbo.news where contains (text, 'METTE')
print 'LUCE'
select count(*) from unisys.dbo.news where contains (text, 'LUCE')
print 'PAROLA'
select count(*) from unisys.dbo.news where contains (text, 'PAROLA')
print 'VIENE'
select count(*) from unisys.dbo.news where contains (text, 'VIENE')
print 'SCENA'
select count(*) from unisys.dbo.news where contains (text, 'SCENA')
print 'ELEZIONI'
select count(*) from unisys.dbo.news where contains (text, 'ELEZIONI')
print 'VITTORIO'
select count(*) from unisys.dbo.news where contains (text, 'VITTORIO')
print 'VITTORIA'
select count(*) from unisys.dbo.news where contains (text, 'VITTORIA')
print 'POSTO'
select count(*) from unisys.dbo.news where contains (text, 'POSTO')
print 'PRESENZA'
select count(*) from unisys.dbo.news where contains (text, 'PRESENZA')
print 'MAURIZIO'
select count(*) from unisys.dbo.news where contains (text, 'MAURIZIO')
print 'EFFETTI'
select count(*) from unisys.dbo.news where contains (text, 'EFFETTI')
print 'PIEMONTE'
select count(*) from unisys.dbo.news where contains (text, 'PIEMONTE')
print 'CAMPIONATO'
select count(*) from unisys.dbo.news where contains (text, 'CAMPIONATO')
print 'RACCONTA'
select count(*) from unisys.dbo.news where contains (text, 'RACCONTA')
print 'NATURALMENTE'
select count(*) from unisys.dbo.news where contains (text, 'NATURALMENTE')
print 'LASCIA'
select count(*) from unisys.dbo.news where contains (text, 'LASCIA')
print 'CENTRO'
select count(*) from unisys.dbo.news where contains (text, 'CENTRO')
print 'SERA'
select count(*) from unisys.dbo.news where contains (text, 'SERA')
print 'UNICO'
select count(*) from unisys.dbo.news where contains (text, 'UNICO')
print 'ACQUA'
select count(*) from unisys.dbo.news where contains (text, 'ACQUA')
print 'EUROPEA'
select count(*) from unisys.dbo.news where contains (text, 'EUROPEA')
print 'ESISTE'
select count(*) from unisys.dbo.news where contains (text, 'ESISTE')
print 'AVUTO'
select count(*) from unisys.dbo.news where contains (text, 'AVUTO')
print 'MILA'
select count(*) from unisys.dbo.news where contains (text, 'MILA')
print 'STESSI'
select count(*) from unisys.dbo.news where contains (text, 'STESSI')
print 'INIZIATIVA'
select count(*) from unisys.dbo.news where contains (text, 'INIZIATIVA')
print 'RIFERIMENTO'
select count(*) from unisys.dbo.news where contains (text, 'RIFERIMENTO')
print 'PROBLEMA'
select count(*) from unisys.dbo.news where contains (text, 'PROBLEMA')
print 'DOMENICA'
select count(*) from unisys.dbo.news where contains (text, 'DOMENICA')
print 'FANNO'
select count(*) from unisys.dbo.news where contains (text, 'FANNO')
print 'GOVERNO'
select count(*) from unisys.dbo.news where contains (text, 'GOVERNO')
print 'FILM'
select count(*) from unisys.dbo.news where contains (text, 'FILM')
print 'MOLTI'
select count(*) from unisys.dbo.news where contains (text, 'MOLTI')
print 'SABATO'
select count(*) from unisys.dbo.news where contains (text, 'SABATO')
print 'SOCIALE'
select count(*) from unisys.dbo.news where contains (text, 'SOCIALE')
print 'ITALIANI'
select count(*) from unisys.dbo.news where contains (text, 'ITALIANI')
print 'LOCALI'
select count(*) from unisys.dbo.news where contains (text, 'LOCALI')
print 'PERSO'
select count(*) from unisys.dbo.news where contains (text, 'PERSO')
print 'TANTE'
select count(*) from unisys.dbo.news where contains (text, 'TANTE')
print 'ALBERTO'
select count(*) from unisys.dbo.news where contains (text, 'ALBERTO')
print 'FORTE'
select count(*) from unisys.dbo.news where contains (text, 'FORTE')
print 'SUCCESSO'
select count(*) from unisys.dbo.news where contains (text, 'SUCCESSO')
print 'TANTI'
select count(*) from unisys.dbo.news where contains (text, 'TANTI')
print 'PARTIRE'
select count(*) from unisys.dbo.news where contains (text, 'PARTIRE')
print 'PAOLO'
select count(*) from unisys.dbo.news where contains (text, 'PAOLO')
print 'PENSA'
select count(*) from unisys.dbo.news where contains (text, 'PENSA')
print 'CLASSIFICA'
select count(*) from unisys.dbo.news where contains (text, 'CLASSIFICA')
print 'PORTA'
select count(*) from unisys.dbo.news where contains (text, 'PORTA')
print 'NORD'
select count(*) from unisys.dbo.news where contains (text, 'NORD')
print 'EPPURE'
select count(*) from unisys.dbo.news where contains (text, 'EPPURE')
print 'ACCUSA'
select count(*) from unisys.dbo.news where contains (text, 'ACCUSA')
print 'FOSSE'
select count(*) from unisys.dbo.news where contains (text, 'FOSSE')
print 'QUESTIONE'
select count(*) from unisys.dbo.news where contains (text, 'QUESTIONE')
print 'LAVORO'
select count(*) from unisys.dbo.news where contains (text, 'LAVORO')
print 'ACCORDO'
select count(*) from unisys.dbo.news where contains (text, 'ACCORDO')
print 'GRADO'
select count(*) from unisys.dbo.news where contains (text, 'GRADO')
print 'ADDIRITTURA'
select count(*) from unisys.dbo.news where contains (text, 'ADDIRITTURA')
print 'RAPPORTO'
select count(*) from unisys.dbo.news where contains (text, 'RAPPORTO')
print 'NOVEMBRE'
select count(*) from unisys.dbo.news where contains (text, 'NOVEMBRE')
print 'NUMERO'
select count(*) from unisys.dbo.news where contains (text, 'NUMERO')
print 'DOMANDA'
select count(*) from unisys.dbo.news where contains (text, 'DOMANDA')
print 'GIOVANE'
select count(*) from unisys.dbo.news where contains (text, 'GIOVANE')
print 'AGGIUNTO'
select count(*) from unisys.dbo.news where contains (text, 'AGGIUNTO')
print 'CUORE'
select count(*) from unisys.dbo.news where contains (text, 'CUORE')
print 'FIDUCIA'
select count(*) from unisys.dbo.news where contains (text, 'FIDUCIA')
print 'BUON'
select count(*) from unisys.dbo.news where contains (text, 'BUON')
print 'BERLUSCONI'
select count(*) from unisys.dbo.news where contains (text, 'BERLUSCONI')
print 'PICCOLA'
select count(*) from unisys.dbo.news where contains (text, 'PICCOLA')
print 'INTERVENTO'
select count(*) from unisys.dbo.news where contains (text, 'INTERVENTO')
print 'LONTANO'
select count(*) from unisys.dbo.news where contains (text, 'LONTANO')
print 'NAPOLI'
select count(*) from unisys.dbo.news where contains (text, 'NAPOLI')
print 'MARIO'
select count(*) from unisys.dbo.news where contains (text, 'MARIO')
print 'RAGGIUNTO'
select count(*) from unisys.dbo.news where contains (text, 'RAGGIUNTO')
print 'STRADA'
select count(*) from unisys.dbo.news where contains (text, 'STRADA')
print 'POSSIBILIT�'
select count(*) from unisys.dbo.news where contains (text, 'POSSIBILIT�')
print 'TEATRO'
select count(*) from unisys.dbo.news where contains (text, 'TEATRO')
print 'TOTALE'
select count(*) from unisys.dbo.news where contains (text, 'TOTALE')
print 'DOVEVA'
select count(*) from unisys.dbo.news where contains (text, 'DOVEVA')
print 'COMMISSIONE'
select count(*) from unisys.dbo.news where contains (text, 'COMMISSIONE')
print 'ITALIANA'
select count(*) from unisys.dbo.news where contains (text, 'ITALIANA')
print 'PROPOSTA'
select count(*) from unisys.dbo.news where contains (text, 'PROPOSTA')
print 'SEGRETARIO'
select count(*) from unisys.dbo.news where contains (text, 'SEGRETARIO')
print 'ASSOCIAZIONE'
select count(*) from unisys.dbo.news where contains (text, 'ASSOCIAZIONE')
print 'AMORE'
select count(*) from unisys.dbo.news where contains (text, 'AMORE')
print 'RISCHIO'
select count(*) from unisys.dbo.news where contains (text, 'RISCHIO')
print 'IMPORTANTI'
select count(*) from unisys.dbo.news where contains (text, 'IMPORTANTI')
print 'POTREBBERO'
select count(*) from unisys.dbo.news where contains (text, 'POTREBBERO')
print 'NUOVE'
select count(*) from unisys.dbo.news where contains (text, 'NUOVE')
print 'PAGARE'
select count(*) from unisys.dbo.news where contains (text, 'PAGARE')
print 'INCONTRO'
select count(*) from unisys.dbo.news where contains (text, 'INCONTRO')
print 'VEDERE'
select count(*) from unisys.dbo.news where contains (text, 'VEDERE')
print 'RESPONSABILE'
select count(*) from unisys.dbo.news where contains (text, 'RESPONSABILE')
print 'VOGLIO'
select count(*) from unisys.dbo.news where contains (text, 'VOGLIO')
print 'TERZA'
select count(*) from unisys.dbo.news where contains (text, 'TERZA')
print 'DIFESA'
select count(*) from unisys.dbo.news where contains (text, 'DIFESA')
print 'PERSONALE'
select count(*) from unisys.dbo.news where contains (text, 'PERSONALE')
print 'ARRIVARE'
select count(*) from unisys.dbo.news where contains (text, 'ARRIVARE')
print 'ALLORA'
select count(*) from unisys.dbo.news where contains (text, 'ALLORA')
print 'DIFFICOLT�'
select count(*) from unisys.dbo.news where contains (text, 'DIFFICOLT�')
print 'ACCANTO'
select count(*) from unisys.dbo.news where contains (text, 'ACCANTO')
print 'BISOGNO'
select count(*) from unisys.dbo.news where contains (text, 'BISOGNO')
print 'PRESENTE'
select count(*) from unisys.dbo.news where contains (text, 'PRESENTE')
print 'CHIESA'
select count(*) from unisys.dbo.news where contains (text, 'CHIESA')
print 'EUROPA'
select count(*) from unisys.dbo.news where contains (text, 'EUROPA')
print 'CREDO'
select count(*) from unisys.dbo.news where contains (text, 'CREDO')
print 'PRESTO'
select count(*) from unisys.dbo.news where contains (text, 'PRESTO')
print 'DIVERSE'
select count(*) from unisys.dbo.news where contains (text, 'DIVERSE')
print 'PROCESSO'
select count(*) from unisys.dbo.news where contains (text, 'PROCESSO')
print 'SAREBBERO'
select count(*) from unisys.dbo.news where contains (text, 'SAREBBERO')
print 'DAVVERO'
select count(*) from unisys.dbo.news where contains (text, 'DAVVERO')
print 'SIANO'
select count(*) from unisys.dbo.news where contains (text, 'SIANO')
print 'QUALSIASI'
select count(*) from unisys.dbo.news where contains (text, 'QUALSIASI')
print 'PACE'
select count(*) from unisys.dbo.news where contains (text, 'PACE')
print 'PARE'
select count(*) from unisys.dbo.news where contains (text, 'PARE')
print 'OSPEDALE'
select count(*) from unisys.dbo.news where contains (text, 'OSPEDALE')
print 'AUTO'
select count(*) from unisys.dbo.news where contains (text, 'AUTO')
print 'QUEST'
select count(*) from unisys.dbo.news where contains (text, 'QUEST')
print 'POLITICI'
select count(*) from unisys.dbo.news where contains (text, 'POLITICI')
print 'ROBERTO'
select count(*) from unisys.dbo.news where contains (text, 'ROBERTO')
print 'STAMPA'
select count(*) from unisys.dbo.news where contains (text, 'STAMPA')
print 'MANI'
select count(*) from unisys.dbo.news where contains (text, 'MANI')
print 'AVREBBERO'
select count(*) from unisys.dbo.news where contains (text, 'AVREBBERO')
print 'IMPEGNO'
select count(*) from unisys.dbo.news where contains (text, 'IMPEGNO')
print 'INGRESSO'
select count(*) from unisys.dbo.news where contains (text, 'INGRESSO')
print 'INFORMAZIONI'
select count(*) from unisys.dbo.news where contains (text, 'INFORMAZIONI')
print 'SERATA'
select count(*) from unisys.dbo.news where contains (text, 'SERATA')
print 'CASI'
select count(*) from unisys.dbo.news where contains (text, 'CASI')
print 'SEDE'
select count(*) from unisys.dbo.news where contains (text, 'SEDE')
print 'TUTTAVIA'
select count(*) from unisys.dbo.news where contains (text, 'TUTTAVIA')
print 'TORINESE'
select count(*) from unisys.dbo.news where contains (text, 'TORINESE')
print 'SVILUPPO'
select count(*) from unisys.dbo.news where contains (text, 'SVILUPPO')
print 'ATTIVIT�'
select count(*) from unisys.dbo.news where contains (text, 'ATTIVIT�')
print 'VOGLIONO'
select count(*) from unisys.dbo.news where contains (text, 'VOGLIONO')
print 'GIUSEPPE'
select count(*) from unisys.dbo.news where contains (text, 'GIUSEPPE')
print 'PIENO'
select count(*) from unisys.dbo.news where contains (text, 'PIENO')
print 'SPAZIO'
select count(*) from unisys.dbo.news where contains (text, 'SPAZIO')
print 'LASCIATO'
select count(*) from unisys.dbo.news where contains (text, 'LASCIATO')
print 'ERANO'
select count(*) from unisys.dbo.news where contains (text, 'ERANO')
print 'PASSARE'
select count(*) from unisys.dbo.news where contains (text, 'PASSARE')
print 'MARCO'
select count(*) from unisys.dbo.news where contains (text, 'MARCO')
print 'NEMMENO'
select count(*) from unisys.dbo.news where contains (text, 'NEMMENO')
print 'INVIATO'
select count(*) from unisys.dbo.news where contains (text, 'INVIATO')
print 'CORSO'
select count(*) from unisys.dbo.news where contains (text, 'CORSO')
print 'BUONA'
select count(*) from unisys.dbo.news where contains (text, 'BUONA')
print 'VEDE'
select count(*) from unisys.dbo.news where contains (text, 'VEDE')
print 'MIEI'
select count(*) from unisys.dbo.news where contains (text, 'MIEI')
print 'RISULTATI'
select count(*) from unisys.dbo.news where contains (text, 'RISULTATI')
print 'PARTI'
select count(*) from unisys.dbo.news where contains (text, 'PARTI')
print 'PAESI'
select count(*) from unisys.dbo.news where contains (text, 'PAESI')
print 'UOMO'
select count(*) from unisys.dbo.news where contains (text, 'UOMO')
print 'INTERNAZIONALE'
select count(*) from unisys.dbo.news where contains (text, 'INTERNAZIONALE')
print 'LEADER'
select count(*) from unisys.dbo.news where contains (text, 'LEADER')
print 'BENE'
select count(*) from unisys.dbo.news where contains (text, 'BENE')
print 'PALAZZO'
select count(*) from unisys.dbo.news where contains (text, 'PALAZZO')
print 'FAR�'
select count(*) from unisys.dbo.news where contains (text, 'FAR�')
print 'GIUSTO'
select count(*) from unisys.dbo.news where contains (text, 'GIUSTO')
print 'FORMAZIONE'
select count(*) from unisys.dbo.news where contains (text, 'FORMAZIONE')
print 'CIO�'
select count(*) from unisys.dbo.news where contains (text, 'CIO�')
print 'ASSESSORE'
select count(*) from unisys.dbo.news where contains (text, 'ASSESSORE')
print 'CERTO'
select count(*) from unisys.dbo.news where contains (text, 'CERTO')
print 'POCO'
select count(*) from unisys.dbo.news where contains (text, 'POCO')
print 'CHIARO'
select count(*) from unisys.dbo.news where contains (text, 'CHIARO')
print 'SINDACO'
select count(*) from unisys.dbo.news where contains (text, 'SINDACO')
print 'SINO'
select count(*) from unisys.dbo.news where contains (text, 'SINO')
print 'OPERA'
select count(*) from unisys.dbo.news where contains (text, 'OPERA')
print 'LEGA'
select count(*) from unisys.dbo.news where contains (text, 'LEGA')
print 'PORTATO'
select count(*) from unisys.dbo.news where contains (text, 'PORTATO')
print 'AVER'
select count(*) from unisys.dbo.news where contains (text, 'AVER')
print 'SPETTACOLO'
select count(*) from unisys.dbo.news where contains (text, 'SPETTACOLO')
print 'DIVENTA'
select count(*) from unisys.dbo.news where contains (text, 'DIVENTA')
print 'PARIGI'
select count(*) from unisys.dbo.news where contains (text, 'PARIGI')
print 'DIECI'
select count(*) from unisys.dbo.news where contains (text, 'DIECI')
print 'CHIEDERE'
select count(*) from unisys.dbo.news where contains (text, 'CHIEDERE')
print 'UNICA'
select count(*) from unisys.dbo.news where contains (text, 'UNICA')
print 'AVERE'
select count(*) from unisys.dbo.news where contains (text, 'AVERE')
print 'PROVINCIA'
select count(*) from unisys.dbo.news where contains (text, 'PROVINCIA')
print 'SOSTIENE'
select count(*) from unisys.dbo.news where contains (text, 'SOSTIENE')
print 'DOMANI'
select count(*) from unisys.dbo.news where contains (text, 'DOMANI')
print 'FUOCO'
select count(*) from unisys.dbo.news where contains (text, 'FUOCO')
print 'SPALLE'
select count(*) from unisys.dbo.news where contains (text, 'SPALLE')
print 'INTERESSE'
select count(*) from unisys.dbo.news where contains (text, 'INTERESSE')
