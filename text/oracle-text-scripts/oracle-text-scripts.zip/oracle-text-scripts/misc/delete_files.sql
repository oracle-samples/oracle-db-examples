$ del h:\oracle\oradata\ses\cache\I1DS341\432\4328325                           
