-- set time on
set timing on
set echo on
-- set autotrace traceonly
