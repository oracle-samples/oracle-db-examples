connect internal
shutdown immediate
startup
connect roger/roger
set time on
set timing on
set autotrace traceonly
