select * from docs where contains (filename, '
vaccinations and poverty
') > 0;
select * from docs where contains (filename, '
about(vaccinations) and about(poverty)
') > 0;
