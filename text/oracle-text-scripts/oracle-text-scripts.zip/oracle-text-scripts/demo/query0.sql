select * from docs 
where contains (filename, '
configuration manager 
') > 0;
