Various examples of USER_DATASTORE procedures
