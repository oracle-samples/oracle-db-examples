exec ctx_thes.drop_thesaurus('default') 
quit
