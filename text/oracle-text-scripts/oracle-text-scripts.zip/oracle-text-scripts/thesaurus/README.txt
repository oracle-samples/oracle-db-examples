Various scripts relating the thesaurus functions
