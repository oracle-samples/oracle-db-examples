This is a query parser intended to take simple user input
(a Google-like search) and translate it to a text query
There are various options but prog_relax is the most effective

The script should be unbreakable - whatever rubbish a user types,
we will attempt to do something useful with it. There is a limited
syntax defined for required words, words to exclude, and phrases.

The latest versio nis parser_v0991.pls

There are a few 'forks' which implement specific features as requested 
by certain customers.
