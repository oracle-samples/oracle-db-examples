SQL> 
SQL> spool off
