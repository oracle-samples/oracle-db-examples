create index avtest_index on avtest ( text ) indextype is ctxsys.context; 	

