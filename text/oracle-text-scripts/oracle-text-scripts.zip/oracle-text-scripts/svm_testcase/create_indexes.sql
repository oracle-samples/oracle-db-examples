create index test.brain_ctx on test.brain(abstract) indextype is ctxsys.context;
create index test.cancer_ctx on test.cancer(abstract) indextype is ctxsys.context;
create index test.maternal_ctx on test.maternal(abstract) indextype is ctxsys.context;
create index test.microbes_ctx on test.microbes(abstract) indextype is ctxsys.context;
create index test.synmed_ctx on test.synmed(abstract) indextype is ctxsys.context;
