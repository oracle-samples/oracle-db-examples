sqlldr userid=test/qj98zslh control=brain.ctl log=load_brain.log bad=load_brain.bad
sqlldr userid=test/qj98zslh control=cancer.ctl log=load_cancer.log bad=load_cancer.bad
sqlldr userid=test/qj98zslh control=maternal.ctl log=load_maternal.log bad=load_maternal.bad
sqlldr userid=test/qj98zslh control=microbes.ctl log=load_microbes.log bad=load_microbes.bad
sqlldr userid=test/qj98zslh control=synmed.ctl log=load_synmed.log bad=load_synmed.bad
