prog_relax.html has an old, but useful blog post (sadly now deleted) about
Progressive Relaxation. It's well worth reading.
